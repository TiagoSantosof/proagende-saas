
'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { Loader2 } from 'lucide-react';

interface SubscriptionCheckerProps {
  children: React.ReactNode;
}

export default function SubscriptionChecker({ children }: SubscriptionCheckerProps) {
  const { data: session, status } = useSession() || {};
  const router = useRouter();
  const [isChecking, setIsChecking] = useState(true);

  useEffect(() => {
    const checkSubscription = async () => {
      if (status === 'loading') return;
      
      if (!session?.user) {
        router.push('/auth/login');
        return;
      }

      // Só verificar se for proprietário
      if (session.user.role === 'OWNER') {
        try {
          const response = await fetch('/api/check-subscription');
          const data = await response.json();

          if (data.needsPlan || !data.hasValidSubscription) {
            // Se precisa de plano ou não tem assinatura válida, redirecionar
            if (data.hasValidSubscription === false) {
              router.push('/subscription-expired');
            } else {
              router.push('/plans');
            }
            return;
          }
        } catch (error) {
          console.error('Erro ao verificar assinatura:', error);
          // Em caso de erro de conexão, permitir acesso temporário
          // mas mostrar aviso
          console.warn('Erro de conexão na verificação de assinatura - permitindo acesso temporário');
        }
      }

      setIsChecking(false);
    };

    checkSubscription();
  }, [session, status, router]);

  if (status === 'loading' || isChecking) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600">Verificando acesso...</p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
