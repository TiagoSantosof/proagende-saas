
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'react-hot-toast';
import { CalendarDays, Clock, User, FileText } from 'lucide-react';

interface AppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  professionals: any[];
  services: any[];
}

interface AppointmentFormData {
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  professionalId: string;
  serviceId: string;
  date: string;
  time: string;
  notes?: string;
}

export default function AppointmentModal({ isOpen, onClose, professionals, services }: AppointmentModalProps) {
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();
  
  const { register, handleSubmit, reset, setValue, watch, formState: { errors } } = useForm<AppointmentFormData>();
  
  const selectedService = services?.find(service => service.id === watch('serviceId'));

  const onSubmit = async (data: AppointmentFormData) => {
    setIsLoading(true);
    try {
      // Combine date and time
      const appointmentDateTime = new Date(`${data.date}T${data.time}`);
      
      const response = await fetch('/api/appointments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          customerName: data.customerName,
          customerEmail: data.customerEmail,
          customerPhone: data.customerPhone,
          professionalId: data.professionalId,
          serviceId: data.serviceId,
          date: appointmentDateTime.toISOString(),
          notes: data.notes,
        }),
      });

      if (!response.ok) {
        throw new Error('Erro ao criar agendamento');
      }

      toast.success('Agendamento criado com sucesso!');
      reset();
      onClose();
      router.refresh();
    } catch (error) {
      console.error('Error creating appointment:', error);
      toast.error('Erro ao criar agendamento. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    reset();
    onClose();
  };

  // Get tomorrow's date as minimum date
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const minDate = tomorrow.toISOString().split('T')[0];

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <CalendarDays className="w-5 h-5 text-blue-600" />
            <span>Novo Agendamento</span>
          </DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          {/* Customer Information */}
          <div className="space-y-4">
            <h3 className="font-medium text-gray-900 flex items-center space-x-2">
              <User className="w-4 h-4" />
              <span>Informações do Cliente</span>
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="customerName">Nome *</Label>
                <Input
                  id="customerName"
                  {...register('customerName', { required: 'Nome é obrigatório' })}
                  placeholder="Nome completo do cliente"
                />
                {errors.customerName && (
                  <span className="text-sm text-red-500">{errors.customerName.message}</span>
                )}
              </div>
              
              <div>
                <Label htmlFor="customerPhone">Telefone *</Label>
                <Input
                  id="customerPhone"
                  {...register('customerPhone', { required: 'Telefone é obrigatório' })}
                  placeholder="(11) 99999-9999"
                />
                {errors.customerPhone && (
                  <span className="text-sm text-red-500">{errors.customerPhone.message}</span>
                )}
              </div>
            </div>
            
            <div>
              <Label htmlFor="customerEmail">E-mail</Label>
              <Input
                id="customerEmail"
                type="email"
                {...register('customerEmail')}
                placeholder="email@exemplo.com"
              />
            </div>
          </div>

          {/* Service Selection */}
          <div className="space-y-4">
            <h3 className="font-medium text-gray-900">Serviço e Profissional</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Serviço *</Label>
                <Select onValueChange={(value) => setValue('serviceId', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um serviço" />
                  </SelectTrigger>
                  <SelectContent>
                    {services?.map((service) => (
                      <SelectItem key={service.id} value={service.id}>
                        <div className="flex flex-col">
                          <span>{service.name}</span>
                          <span className="text-sm text-gray-500">
                            R$ {service.price?.toFixed(2)} - {service.duration}min
                          </span>
                        </div>
                      </SelectItem>
                    )) || []}
                  </SelectContent>
                </Select>
                {errors.serviceId && (
                  <span className="text-sm text-red-500">Selecione um serviço</span>
                )}
              </div>
              
              <div>
                <Label>Profissional *</Label>
                <Select onValueChange={(value) => setValue('professionalId', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um profissional" />
                  </SelectTrigger>
                  <SelectContent>
                    {professionals?.filter(prof => prof.isActive).map((professional) => (
                      <SelectItem key={professional.id} value={professional.id}>
                        <div className="flex flex-col">
                          <span>{professional.name}</span>
                          <span className="text-sm text-gray-500">{professional.specialties?.join(', ') || 'Sem especialidade'}</span>
                        </div>
                      </SelectItem>
                    )) || []}
                  </SelectContent>
                </Select>
                {errors.professionalId && (
                  <span className="text-sm text-red-500">Selecione um profissional</span>
                )}
              </div>
            </div>
          </div>

          {/* Date and Time */}
          <div className="space-y-4">
            <h3 className="font-medium text-gray-900 flex items-center space-x-2">
              <Clock className="w-4 h-4" />
              <span>Data e Horário</span>
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="date">Data *</Label>
                <Input
                  id="date"
                  type="date"
                  min={minDate}
                  {...register('date', { required: 'Data é obrigatória' })}
                />
                {errors.date && (
                  <span className="text-sm text-red-500">{errors.date.message}</span>
                )}
              </div>
              
              <div>
                <Label htmlFor="time">Horário *</Label>
                <Input
                  id="time"
                  type="time"
                  {...register('time', { required: 'Horário é obrigatório' })}
                />
                {errors.time && (
                  <span className="text-sm text-red-500">{errors.time.message}</span>
                )}
              </div>
            </div>
          </div>

          {/* Notes */}
          <div>
            <Label htmlFor="notes" className="flex items-center space-x-2">
              <FileText className="w-4 h-4" />
              <span>Observações</span>
            </Label>
            <Textarea
              id="notes"
              {...register('notes')}
              placeholder="Observações sobre o agendamento (opcional)"
              rows={3}
            />
          </div>

          {/* Summary */}
          {selectedService && (
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2">Resumo do Agendamento</h4>
              <div className="text-sm text-blue-800 space-y-1">
                <p><span className="font-medium">Serviço:</span> {selectedService.name}</p>
                <p><span className="font-medium">Duração:</span> {selectedService.duration} minutos</p>
                <p><span className="font-medium">Valor:</span> R$ {selectedService.price?.toFixed(2)}</p>
              </div>
            </div>
          )}

          <div className="flex justify-end space-x-3 pt-4">
            <Button type="button" variant="outline" onClick={handleClose} disabled={isLoading}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading} className="bg-blue-600 hover:bg-blue-700">
              {isLoading ? 'Criando...' : 'Criar Agendamento'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
