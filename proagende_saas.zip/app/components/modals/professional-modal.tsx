
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'react-hot-toast';
import { User, Mail, Phone, Briefcase, Clock, Calendar } from 'lucide-react';

interface ProfessionalModalProps {
  isOpen: boolean;
  onClose: () => void;
  professional?: any; // Para edição
  mode?: 'create' | 'edit';
}

interface ProfessionalFormData {
  name: string;
  email: string;
  phone: string;
  specialties: string[];
}

interface WorkingHoursData {
  dayOfWeek: number;
  isWorkingDay: boolean;
  morningStart: string;
  morningEnd: string;
  afternoonStart: string;
  afternoonEnd: string;
}

export default function ProfessionalModal({ isOpen, onClose, professional, mode = 'create' }: ProfessionalModalProps) {
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();
  const [specialty, setSpecialty] = useState('');
  
  // Estado para horários de trabalho
  const [workingHours, setWorkingHours] = useState<WorkingHoursData[]>([
    { dayOfWeek: 0, isWorkingDay: false, morningStart: '08:00', morningEnd: '12:00', afternoonStart: '14:00', afternoonEnd: '18:00' }, // Domingo
    { dayOfWeek: 1, isWorkingDay: true, morningStart: '08:00', morningEnd: '12:00', afternoonStart: '14:00', afternoonEnd: '18:00' },  // Segunda
    { dayOfWeek: 2, isWorkingDay: true, morningStart: '08:00', morningEnd: '12:00', afternoonStart: '14:00', afternoonEnd: '18:00' },  // Terça
    { dayOfWeek: 3, isWorkingDay: true, morningStart: '08:00', morningEnd: '12:00', afternoonStart: '14:00', afternoonEnd: '18:00' },  // Quarta
    { dayOfWeek: 4, isWorkingDay: true, morningStart: '08:00', morningEnd: '12:00', afternoonStart: '14:00', afternoonEnd: '18:00' },  // Quinta
    { dayOfWeek: 5, isWorkingDay: true, morningStart: '08:00', morningEnd: '12:00', afternoonStart: '14:00', afternoonEnd: '18:00' },  // Sexta
    { dayOfWeek: 6, isWorkingDay: false, morningStart: '08:00', morningEnd: '12:00', afternoonStart: '14:00', afternoonEnd: '18:00' }, // Sábado
  ]);

  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm<ProfessionalFormData>();

  const dayNames = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];

  // Carregar dados do profissional para edição
  useEffect(() => {
    if (mode === 'edit' && professional) {
      setValue('name', professional.name);
      setValue('email', professional.email);
      setValue('phone', professional.phone || '');
      setSpecialty(professional.specialties?.join(', ') || '');
      
      // Carregar horários de trabalho se existirem
      if (professional.workingHours) {
        const updatedHours = workingHours.map(hour => {
          const existingHour = professional.workingHours.find((wh: any) => wh.dayOfWeek === hour.dayOfWeek);
          return existingHour ? {
            ...hour,
            isWorkingDay: existingHour.isWorkingDay,
            morningStart: existingHour.morningStart || hour.morningStart,
            morningEnd: existingHour.morningEnd || hour.morningEnd,
            afternoonStart: existingHour.afternoonStart || hour.afternoonStart,
            afternoonEnd: existingHour.afternoonEnd || hour.afternoonEnd,
          } : hour;
        });
        setWorkingHours(updatedHours);
      }
    }
  }, [mode, professional, setValue]);

  const updateWorkingHours = (dayIndex: number, field: string, value: any) => {
    setWorkingHours(prev => prev.map((day, index) => 
      index === dayIndex ? { ...day, [field]: value } : day
    ));
  };

  const onSubmit = async (data: ProfessionalFormData) => {
    setIsLoading(true);
    try {
      const formData = {
        ...data,
        specialties: specialty ? specialty.split(',').map(s => s.trim()).filter(s => s) : [],
        workingHours: workingHours
      };

      const url = mode === 'edit' ? `/api/professionals/${professional.id}` : '/api/professionals';
      const method = mode === 'edit' ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error(`Erro ao ${mode === 'edit' ? 'atualizar' : 'criar'} profissional`);
      }

      toast.success(`Profissional ${mode === 'edit' ? 'atualizado' : 'cadastrado'} com sucesso!`);
      reset();
      onClose();
      router.refresh();
    } catch (error) {
      console.error('Error saving professional:', error);
      toast.error(`Erro ao ${mode === 'edit' ? 'atualizar' : 'cadastrar'} profissional. Tente novamente.`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    reset();
    setSpecialty('');
    // Reset working hours to default
    setWorkingHours([
      { dayOfWeek: 0, isWorkingDay: false, morningStart: '08:00', morningEnd: '12:00', afternoonStart: '14:00', afternoonEnd: '18:00' },
      { dayOfWeek: 1, isWorkingDay: true, morningStart: '08:00', morningEnd: '12:00', afternoonStart: '14:00', afternoonEnd: '18:00' },
      { dayOfWeek: 2, isWorkingDay: true, morningStart: '08:00', morningEnd: '12:00', afternoonStart: '14:00', afternoonEnd: '18:00' },
      { dayOfWeek: 3, isWorkingDay: true, morningStart: '08:00', morningEnd: '12:00', afternoonStart: '14:00', afternoonEnd: '18:00' },
      { dayOfWeek: 4, isWorkingDay: true, morningStart: '08:00', morningEnd: '12:00', afternoonStart: '14:00', afternoonEnd: '18:00' },
      { dayOfWeek: 5, isWorkingDay: true, morningStart: '08:00', morningEnd: '12:00', afternoonStart: '14:00', afternoonEnd: '18:00' },
      { dayOfWeek: 6, isWorkingDay: false, morningStart: '08:00', morningEnd: '12:00', afternoonStart: '14:00', afternoonEnd: '18:00' },
    ]);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[800px] max-h-[90vh] flex flex-col">
        <DialogHeader className="shrink-0">
          <DialogTitle className="flex items-center space-x-2">
            <User className="w-5 h-5 text-blue-600" />
            <span>{mode === 'edit' ? 'Editar Profissional' : 'Cadastrar Novo Profissional'}</span>
          </DialogTitle>
        </DialogHeader>
        
        <div className="flex-1 overflow-y-auto px-1">
          <Tabs defaultValue="basic" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="basic" className="flex items-center space-x-2">
                <User className="w-4 h-4" />
                <span>Dados Básicos</span>
              </TabsTrigger>
              <TabsTrigger value="schedule" className="flex items-center space-x-2">
                <Calendar className="w-4 h-4" />
                <span>Horários de Trabalho</span>
              </TabsTrigger>
            </TabsList>

            <form onSubmit={handleSubmit(onSubmit)} className="mt-6">
              <TabsContent value="basic" className="space-y-4">
                <div className="space-y-4">
                  <h3 className="font-medium text-gray-900">Informações do Profissional</h3>
                  
                  <div>
                    <Label htmlFor="name" className="flex items-center space-x-1">
                      <User className="w-4 h-4" />
                      <span>Nome Completo *</span>
                    </Label>
                    <Input
                      id="name"
                      {...register('name', { required: 'Nome é obrigatório' })}
                      placeholder="Nome completo do profissional"
                    />
                    {errors.name && (
                      <span className="text-sm text-red-500">{errors.name.message}</span>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="email" className="flex items-center space-x-1">
                        <Mail className="w-4 h-4" />
                        <span>E-mail *</span>
                      </Label>
                      <Input
                        id="email"
                        type="email"
                        {...register('email', { 
                          required: 'E-mail é obrigatório',
                          pattern: {
                            value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                            message: 'E-mail inválido'
                          }
                        })}
                        placeholder="email@exemplo.com"
                        disabled={mode === 'edit'}
                      />
                      {errors.email && (
                        <span className="text-sm text-red-500">{errors.email.message}</span>
                      )}
                      {mode === 'edit' && (
                        <p className="text-xs text-gray-500 mt-1">E-mail não pode ser alterado</p>
                      )}
                    </div>
                    
                    <div>
                      <Label htmlFor="phone" className="flex items-center space-x-1">
                        <Phone className="w-4 h-4" />
                        <span>Telefone</span>
                      </Label>
                      <Input
                        id="phone"
                        {...register('phone')}
                        placeholder="(11) 99999-9999"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="specialty" className="flex items-center space-x-1">
                      <Briefcase className="w-4 h-4" />
                      <span>Especialidades</span>
                    </Label>
                    <Input
                      id="specialty"
                      value={specialty}
                      onChange={(e) => setSpecialty(e.target.value)}
                      placeholder="Ex: Corte, Coloração, Escova (separe por vírgula)"
                    />
                    <p className="text-xs text-gray-500 mt-1">Separe múltiplas especialidades por vírgula</p>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="schedule" className="space-y-4">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium text-gray-900">Configuração de Horários</h3>
                    <p className="text-sm text-gray-500">Configure os dias e horários de atendimento</p>
                  </div>
                  
                  <div className="space-y-4 border rounded-lg p-4">
                    {workingHours.map((day, index) => (
                      <div key={day.dayOfWeek} className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <Checkbox
                              checked={day.isWorkingDay}
                              onCheckedChange={(checked) => 
                                updateWorkingHours(index, 'isWorkingDay', checked)
                              }
                            />
                            <Label className="font-medium text-gray-900 min-w-[120px]">
                              {dayNames[day.dayOfWeek]}
                            </Label>
                          </div>
                        </div>
                        
                        {day.isWorkingDay && (
                          <div className="ml-6 pl-4 border-l-2 border-blue-100">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              {/* Turno da Manhã */}
                              <div className="space-y-2">
                                <Label className="flex items-center space-x-2 text-sm font-medium">
                                  <Clock className="w-4 h-4 text-yellow-500" />
                                  <span>Turno da Manhã</span>
                                </Label>
                                <div className="flex items-center space-x-2">
                                  <Input
                                    type="time"
                                    value={day.morningStart}
                                    onChange={(e) => 
                                      updateWorkingHours(index, 'morningStart', e.target.value)
                                    }
                                    className="text-sm"
                                  />
                                  <span className="text-gray-400">às</span>
                                  <Input
                                    type="time"
                                    value={day.morningEnd}
                                    onChange={(e) => 
                                      updateWorkingHours(index, 'morningEnd', e.target.value)
                                    }
                                    className="text-sm"
                                  />
                                </div>
                              </div>
                              
                              {/* Turno da Tarde */}
                              <div className="space-y-2">
                                <Label className="flex items-center space-x-2 text-sm font-medium">
                                  <Clock className="w-4 h-4 text-orange-500" />
                                  <span>Turno da Tarde</span>
                                </Label>
                                <div className="flex items-center space-x-2">
                                  <Input
                                    type="time"
                                    value={day.afternoonStart}
                                    onChange={(e) => 
                                      updateWorkingHours(index, 'afternoonStart', e.target.value)
                                    }
                                    className="text-sm"
                                  />
                                  <span className="text-gray-400">às</span>
                                  <Input
                                    type="time"
                                    value={day.afternoonEnd}
                                    onChange={(e) => 
                                      updateWorkingHours(index, 'afternoonEnd', e.target.value)
                                    }
                                    className="text-sm"
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                        
                        {index < workingHours.length - 1 && <div className="border-b border-gray-100"></div>}
                      </div>
                    ))}
                  </div>

                  <div className="bg-amber-50 p-3 rounded-lg">
                    <h4 className="font-medium text-amber-900 mb-2">💡 Dicas importantes</h4>
                    <ul className="text-sm text-amber-800 space-y-1">
                      <li>• Marque os dias em que o profissional está disponível</li>
                      <li>• Configure os horários de manhã e tarde conforme necessário</li>
                      <li>• Deixe em branco turnos que não são trabalhados</li>
                      <li>• Os clientes só poderão agendar nos horários configurados</li>
                    </ul>
                  </div>
                </div>
              </TabsContent>
            </form>
          </Tabs>
        </div>

        {/* Fixed footer with buttons */}
        <div className="shrink-0 border-t pt-4 mt-4">
          <div className="flex justify-end space-x-3">
            <Button type="button" variant="outline" onClick={handleClose} disabled={isLoading}>
              Cancelar
            </Button>
            <Button 
              type="submit" 
              disabled={isLoading} 
              className="bg-blue-600 hover:bg-blue-700"
              onClick={handleSubmit(onSubmit)}
            >
              {isLoading 
                ? (mode === 'edit' ? 'Atualizando...' : 'Cadastrando...')
                : (mode === 'edit' ? 'Atualizar Profissional' : 'Cadastrar Profissional')
              }
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
