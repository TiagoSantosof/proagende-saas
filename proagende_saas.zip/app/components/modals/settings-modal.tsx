
'use client';

import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Settings, Building2, Bell, User, Shield, CreditCard, Save, Crown, Calendar, AlertTriangle, Clock } from 'lucide-react';
import { toast } from 'react-hot-toast';
import { useSession } from 'next-auth/react';
import Link from 'next/link';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  tenantData?: any;
}

export default function SettingsModal({ isOpen, onClose, tenantData }: SettingsModalProps) {
  const [activeTab, setActiveTab] = useState('profile');
  const [loading, setLoading] = useState(false);
  const [subscriptionInfo, setSubscriptionInfo] = useState<any>(null);
  const [loadingSubscription, setLoadingSubscription] = useState(false);
  const { data: session, update } = useSession();

  // Update profile settings when session changes
  useEffect(() => {
    if (session?.user) {
      setProfileSettings({
        name: session.user.name || '',
        email: session.user.email || '',
      });
    }
  }, [session?.user]);

  // Fetch subscription info when modal opens
  useEffect(() => {
    if (isOpen && session?.user?.role === 'OWNER') {
      fetchSubscriptionInfo();
    }
  }, [isOpen, session?.user?.role]);

  const fetchSubscriptionInfo = async () => {
    if (!session?.user?.id) return;
    
    setLoadingSubscription(true);
    try {
      const response = await fetch('/api/subscription/check');
      if (response.ok) {
        const data = await response.json();
        setSubscriptionInfo(data.subscription);
      }
    } catch (error) {
      console.error('Erro ao buscar informações de assinatura:', error);
    } finally {
      setLoadingSubscription(false);
    }
  };
  
  // Profile settings
  const [profileSettings, setProfileSettings] = useState({
    name: session?.user?.name || '',
    email: session?.user?.email || '',
  });

  // Password change
  const [passwordSettings, setPasswordSettings] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  // General settings
  const [generalSettings, setGeneralSettings] = useState({
    name: tenantData?.name || '',
    description: tenantData?.description || '',
    phone: tenantData?.phone || '',
    email: tenantData?.email || '',
    address: tenantData?.address || '',
    website: tenantData?.website || '',
  });

  // Notification settings
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    smsNotifications: false,
    appointmentReminders: true,
    dailyReports: true,
    weeklyReports: false,
    marketingEmails: false,
  });

  // Business settings
  const [businessSettings, setBusinessSettings] = useState({
    timezone: 'America/Sao_Paulo',
    currency: 'BRL',
    language: 'pt-BR',
    workingDays: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'],
    workingHours: {
      start: '08:00',
      end: '18:00'
    },
    appointmentDuration: 60,
    advanceBookingDays: 30,
  });

  const handleSaveProfile = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/settings/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(profileSettings)
      });

      if (response.ok) {
        const data = await response.json();
        await update({ name: profileSettings.name, email: profileSettings.email });
        toast.success('Perfil atualizado com sucesso!');
      } else {
        const errorData = await response.json();
        toast.error(errorData.error || 'Erro ao atualizar perfil');
      }
    } catch (error) {
      toast.error('Erro ao atualizar perfil');
    } finally {
      setLoading(false);
    }
  };

  const handleChangePassword = async () => {
    if (passwordSettings.newPassword !== passwordSettings.confirmPassword) {
      toast.error('Nova senha e confirmação não coincidem');
      return;
    }

    if (passwordSettings.newPassword.length < 8) {
      toast.error('Nova senha deve ter pelo menos 8 caracteres');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/settings/password', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          currentPassword: passwordSettings.currentPassword,
          newPassword: passwordSettings.newPassword
        })
      });

      if (response.ok) {
        toast.success('Senha alterada com sucesso!');
        setPasswordSettings({ currentPassword: '', newPassword: '', confirmPassword: '' });
      } else {
        const errorData = await response.json();
        toast.error(errorData.error || 'Erro ao alterar senha');
      }
    } catch (error) {
      toast.error('Erro ao alterar senha');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveGeneral = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/settings/general', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(generalSettings)
      });

      if (response.ok) {
        toast.success('Configurações gerais salvas com sucesso!');
      } else {
        toast.error('Erro ao salvar configurações gerais');
      }
    } catch (error) {
      toast.error('Erro ao salvar configurações gerais');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveNotifications = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/settings/notifications', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(notificationSettings)
      });

      if (response.ok) {
        toast.success('Configurações de notificações salvas com sucesso!');
      } else {
        toast.error('Erro ao salvar configurações de notificações');
      }
    } catch (error) {
      toast.error('Erro ao salvar configurações de notificações');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveBusiness = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/settings/business', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(businessSettings)
      });

      if (response.ok) {
        toast.success('Configurações do negócio salvas com sucesso!');
      } else {
        toast.error('Erro ao salvar configurações do negócio');
      }
    } catch (error) {
      toast.error('Erro ao salvar configurações do negócio');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Settings className="w-5 h-5" />
            <span>Configurações</span>
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="profile" className="flex items-center space-x-2">
              <User className="w-4 h-4" />
              <span>Perfil</span>
            </TabsTrigger>
            <TabsTrigger value="subscription" className="flex items-center space-x-2">
              <CreditCard className="w-4 h-4" />
              <span>Plano</span>
            </TabsTrigger>
            <TabsTrigger value="general" className="flex items-center space-x-2">
              <Building2 className="w-4 h-4" />
              <span>Empresa</span>
            </TabsTrigger>
            <TabsTrigger value="notifications" className="flex items-center space-x-2">
              <Bell className="w-4 h-4" />
              <span>Notificações</span>
            </TabsTrigger>
            <TabsTrigger value="business" className="flex items-center space-x-2">
              <Shield className="w-4 h-4" />
              <span>Sistema</span>
            </TabsTrigger>
          </TabsList>

          <ScrollArea className="h-[500px] mt-4">
            <TabsContent value="profile" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Dados Pessoais</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="profileName">Nome Completo</Label>
                      <Input
                        id="profileName"
                        value={profileSettings.name}
                        onChange={(e) => setProfileSettings(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="Seu nome completo"
                      />
                    </div>
                    <div>
                      <Label htmlFor="profileEmail">E-mail</Label>
                      <Input
                        id="profileEmail"
                        type="email"
                        value={profileSettings.email}
                        onChange={(e) => setProfileSettings(prev => ({ ...prev, email: e.target.value }))}
                        placeholder="seu@email.com"
                      />
                    </div>
                  </div>

                  <Button onClick={handleSaveProfile} disabled={loading}>
                    <Save className="w-4 h-4 mr-2" />
                    {loading ? 'Salvando...' : 'Salvar Dados'}
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Alterar Senha</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="currentPassword">Senha Atual</Label>
                    <Input
                      id="currentPassword"
                      type="password"
                      value={passwordSettings.currentPassword}
                      onChange={(e) => setPasswordSettings(prev => ({ ...prev, currentPassword: e.target.value }))}
                      placeholder="Digite sua senha atual"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="newPassword">Nova Senha</Label>
                      <Input
                        id="newPassword"
                        type="password"
                        value={passwordSettings.newPassword}
                        onChange={(e) => setPasswordSettings(prev => ({ ...prev, newPassword: e.target.value }))}
                        placeholder="Mínimo 8 caracteres"
                      />
                    </div>
                    <div>
                      <Label htmlFor="confirmPassword">Confirmar Nova Senha</Label>
                      <Input
                        id="confirmPassword"
                        type="password"
                        value={passwordSettings.confirmPassword}
                        onChange={(e) => setPasswordSettings(prev => ({ ...prev, confirmPassword: e.target.value }))}
                        placeholder="Confirme a nova senha"
                      />
                    </div>
                  </div>

                  <Button onClick={handleChangePassword} disabled={loading}>
                    <Shield className="w-4 h-4 mr-2" />
                    {loading ? 'Alterando...' : 'Alterar Senha'}
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="subscription" className="space-y-4">
              {loadingSubscription ? (
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-center">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <>
                  {/* Alerta de vencimento próximo */}
                  {subscriptionInfo && subscriptionInfo.isActive && subscriptionInfo.daysUntilExpiration !== null && subscriptionInfo.daysUntilExpiration <= 7 && (
                    <Alert className="border-orange-200 bg-orange-50">
                      <AlertTriangle className="h-4 w-4 text-orange-600" />
                      <AlertDescription className="text-orange-800">
                        <strong>Atenção!</strong> Sua assinatura expira em{' '}
                        <strong>{subscriptionInfo.daysUntilExpiration} dias</strong>.
                        Renove seu plano para continuar usando o sistema.
                      </AlertDescription>
                    </Alert>
                  )}

                  {/* Alerta de plano expirado */}
                  {subscriptionInfo && !subscriptionInfo.isActive && (
                    <Alert className="border-red-200 bg-red-50">
                      <Clock className="h-4 w-4 text-red-600" />
                      <AlertDescription className="text-red-800">
                        <strong>Plano Expirado!</strong> Sua assinatura não está mais ativa. 
                        Renove seu plano para continuar usando todas as funcionalidades.
                      </AlertDescription>
                    </Alert>
                  )}

                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center space-x-2">
                        <Crown className="w-5 h-5 text-yellow-500" />
                        <span>Seu Plano Atual</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="flex items-center justify-between p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900">
                            {(subscriptionInfo?.subscriptionPlan || tenantData?.subscriptionPlan) === 'MONTHLY' && 'Plano Mensal'}
                            {(subscriptionInfo?.subscriptionPlan || tenantData?.subscriptionPlan) === 'QUARTERLY' && 'Plano Trimestral'}
                            {(subscriptionInfo?.subscriptionPlan || tenantData?.subscriptionPlan) === 'ANNUAL' && 'Plano Anual'}
                            {!(subscriptionInfo?.subscriptionPlan || tenantData?.subscriptionPlan) && 'Nenhum Plano Ativo'}
                          </h3>
                          <p className="text-gray-600">
                            {(subscriptionInfo?.subscriptionPlan || tenantData?.subscriptionPlan) === 'MONTHLY' && 'R$ 89,00/mês'}
                            {(subscriptionInfo?.subscriptionPlan || tenantData?.subscriptionPlan) === 'QUARTERLY' && 'R$ 199,00/trimestre (25% desconto)'}
                            {(subscriptionInfo?.subscriptionPlan || tenantData?.subscriptionPlan) === 'ANNUAL' && '10x R$ 69,90 (35% desconto)'}
                            {!(subscriptionInfo?.subscriptionPlan || tenantData?.subscriptionPlan) && 'Cadastre um plano para usar o sistema'}
                          </p>
                        </div>
                        <Badge 
                          className={`${
                            (subscriptionInfo?.subscriptionStatus || tenantData?.subscriptionStatus) === 'ACTIVE' 
                              ? 'bg-green-100 text-green-800' 
                              : (subscriptionInfo?.subscriptionStatus || tenantData?.subscriptionStatus) === 'PENDING'
                              ? 'bg-yellow-100 text-yellow-800'
                              : 'bg-red-100 text-red-800'
                          }`}
                        >
                          {(subscriptionInfo?.subscriptionStatus || tenantData?.subscriptionStatus) === 'ACTIVE' && 'Ativo'}
                          {(subscriptionInfo?.subscriptionStatus || tenantData?.subscriptionStatus) === 'PENDING' && 'Pendente'}
                          {(subscriptionInfo?.subscriptionStatus || tenantData?.subscriptionStatus) === 'CANCELED' && 'Cancelado'}
                          {(subscriptionInfo?.subscriptionStatus || tenantData?.subscriptionStatus) === 'EXPIRED' && 'Expirado'}
                          {!(subscriptionInfo?.subscriptionStatus || tenantData?.subscriptionStatus) && 'Inativo'}
                        </Badge>
                      </div>

                      {(subscriptionInfo?.subscriptionEndsAt || tenantData?.subscriptionEndsAt) && (
                        <div className="flex items-center space-x-2 text-gray-600">
                          <Calendar className="w-4 h-4" />
                          <span>
                            Renovação em: {new Date(subscriptionInfo?.subscriptionEndsAt || tenantData?.subscriptionEndsAt).toLocaleDateString('pt-BR')}
                          </span>
                          {subscriptionInfo?.daysUntilExpiration !== null && (
                            <span className={`font-medium ${subscriptionInfo.daysUntilExpiration <= 7 ? 'text-orange-600' : 'text-gray-600'}`}>
                              ({subscriptionInfo.daysUntilExpiration > 0 
                                ? `${subscriptionInfo.daysUntilExpiration} dias` 
                                : 'Vencido'})
                            </span>
                          )}
                        </div>
                      )}

                      <div className="space-y-3">
                        <h4 className="font-medium text-gray-900">Benefícios do seu plano:</h4>
                        <ul className="space-y-2 text-gray-600">
                          <li className="flex items-center space-x-2">
                            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                            <span>Agendamentos ilimitados</span>
                          </li>
                          <li className="flex items-center space-x-2">
                            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                            <span>Múltiplos profissionais</span>
                          </li>
                          <li className="flex items-center space-x-2">
                            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                            <span>Relatórios detalhados</span>
                          </li>
                          <li className="flex items-center space-x-2">
                            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                            <span>Suporte técnico</span>
                          </li>
                        </ul>
                      </div>

                      {(!subscriptionInfo?.isActive && (subscriptionInfo?.subscriptionStatus || tenantData?.subscriptionStatus) !== 'ACTIVE') && (
                        <div className="pt-4 border-t">
                          <Link href="/" className="block">
                            <Button className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                              <CreditCard className="w-4 h-4 mr-2" />
                              {subscriptionInfo?.subscriptionStatus === 'EXPIRED' ? 'Renovar Plano' : 'Ativar Plano'}
                            </Button>
                          </Link>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </>
              )}
            </TabsContent>

            <TabsContent value="general" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Informações Gerais</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Nome do Estabelecimento</Label>
                      <Input
                        id="name"
                        value={generalSettings.name}
                        onChange={(e) => setGeneralSettings(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="Nome do seu estabelecimento"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">E-mail</Label>
                      <Input
                        id="email"
                        type="email"
                        value={generalSettings.email}
                        onChange={(e) => setGeneralSettings(prev => ({ ...prev, email: e.target.value }))}
                        placeholder="email@exemplo.com"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="phone">Telefone</Label>
                      <Input
                        id="phone"
                        value={generalSettings.phone}
                        onChange={(e) => setGeneralSettings(prev => ({ ...prev, phone: e.target.value }))}
                        placeholder="(11) 99999-9999"
                      />
                    </div>
                    <div>
                      <Label htmlFor="website">Website</Label>
                      <Input
                        id="website"
                        value={generalSettings.website}
                        onChange={(e) => setGeneralSettings(prev => ({ ...prev, website: e.target.value }))}
                        placeholder="https://www.exemplo.com"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="address">Endereço</Label>
                    <Input
                      id="address"
                      value={generalSettings.address}
                      onChange={(e) => setGeneralSettings(prev => ({ ...prev, address: e.target.value }))}
                      placeholder="Rua, número, bairro, cidade"
                    />
                  </div>

                  <div>
                    <Label htmlFor="description">Descrição</Label>
                    <Textarea
                      id="description"
                      value={generalSettings.description}
                      onChange={(e) => setGeneralSettings(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Descreva seu estabelecimento..."
                      rows={3}
                    />
                  </div>

                  <Button onClick={handleSaveGeneral} disabled={loading}>
                    <Save className="w-4 h-4 mr-2" />
                    {loading ? 'Salvando...' : 'Salvar Configurações'}
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="notifications" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Preferências de Notificação</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Notificações por E-mail</Label>
                        <p className="text-sm text-gray-500">Receber notificações importantes por e-mail</p>
                      </div>
                      <Switch
                        checked={notificationSettings.emailNotifications}
                        onCheckedChange={(checked) => 
                          setNotificationSettings(prev => ({ ...prev, emailNotifications: checked }))
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Notificações por SMS</Label>
                        <p className="text-sm text-gray-500">Receber notificações urgentes por SMS</p>
                      </div>
                      <Switch
                        checked={notificationSettings.smsNotifications}
                        onCheckedChange={(checked) => 
                          setNotificationSettings(prev => ({ ...prev, smsNotifications: checked }))
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Lembretes de Agendamento</Label>
                        <p className="text-sm text-gray-500">Receber lembretes sobre próximos agendamentos</p>
                      </div>
                      <Switch
                        checked={notificationSettings.appointmentReminders}
                        onCheckedChange={(checked) => 
                          setNotificationSettings(prev => ({ ...prev, appointmentReminders: checked }))
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Relatórios Diários</Label>
                        <p className="text-sm text-gray-500">Receber resumo diário dos agendamentos</p>
                      </div>
                      <Switch
                        checked={notificationSettings.dailyReports}
                        onCheckedChange={(checked) => 
                          setNotificationSettings(prev => ({ ...prev, dailyReports: checked }))
                        }
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Relatórios Semanais</Label>
                        <p className="text-sm text-gray-500">Receber resumo semanal do desempenho</p>
                      </div>
                      <Switch
                        checked={notificationSettings.weeklyReports}
                        onCheckedChange={(checked) => 
                          setNotificationSettings(prev => ({ ...prev, weeklyReports: checked }))
                        }
                      />
                    </div>
                  </div>

                  <Button onClick={handleSaveNotifications} disabled={loading}>
                    <Save className="w-4 h-4 mr-2" />
                    {loading ? 'Salvando...' : 'Salvar Preferências'}
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="business" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Configurações do Negócio</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="timezone">Fuso Horário</Label>
                      <select
                        id="timezone"
                        className="w-full p-2 border border-gray-300 rounded-md"
                        value={businessSettings.timezone}
                        onChange={(e) => setBusinessSettings(prev => ({ ...prev, timezone: e.target.value }))}
                      >
                        <option value="America/Sao_Paulo">São Paulo (UTC-3)</option>
                        <option value="America/Manaus">Manaus (UTC-4)</option>
                        <option value="America/Rio_Branco">Rio Branco (UTC-5)</option>
                      </select>
                    </div>
                    <div>
                      <Label htmlFor="currency">Moeda</Label>
                      <select
                        id="currency"
                        className="w-full p-2 border border-gray-300 rounded-md"
                        value={businessSettings.currency}
                        onChange={(e) => setBusinessSettings(prev => ({ ...prev, currency: e.target.value }))}
                      >
                        <option value="BRL">Real Brasileiro (R$)</option>
                        <option value="USD">Dólar Americano ($)</option>
                        <option value="EUR">Euro (€)</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="startTime">Horário de Abertura</Label>
                      <Input
                        id="startTime"
                        type="time"
                        value={businessSettings.workingHours.start}
                        onChange={(e) => setBusinessSettings(prev => ({
                          ...prev,
                          workingHours: { ...prev.workingHours, start: e.target.value }
                        }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="endTime">Horário de Fechamento</Label>
                      <Input
                        id="endTime"
                        type="time"
                        value={businessSettings.workingHours.end}
                        onChange={(e) => setBusinessSettings(prev => ({
                          ...prev,
                          workingHours: { ...prev.workingHours, end: e.target.value }
                        }))}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="duration">Duração Padrão (minutos)</Label>
                      <Input
                        id="duration"
                        type="number"
                        value={businessSettings.appointmentDuration}
                        onChange={(e) => setBusinessSettings(prev => ({
                          ...prev,
                          appointmentDuration: parseInt(e.target.value)
                        }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="advanceDays">Antecedência Máxima (dias)</Label>
                      <Input
                        id="advanceDays"
                        type="number"
                        value={businessSettings.advanceBookingDays}
                        onChange={(e) => setBusinessSettings(prev => ({
                          ...prev,
                          advanceBookingDays: parseInt(e.target.value)
                        }))}
                      />
                    </div>
                  </div>

                  <Button onClick={handleSaveBusiness} disabled={loading}>
                    <Save className="w-4 h-4 mr-2" />
                    {loading ? 'Salvando...' : 'Salvar Configurações'}
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>


          </ScrollArea>
        </Tabs>

        <div className="flex justify-end pt-4 border-t space-x-2">
          <Button variant="outline" onClick={onClose}>
            Fechar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
