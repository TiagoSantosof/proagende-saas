
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'react-hot-toast';
import { Briefcase, DollarSign, Clock, FileText } from 'lucide-react';

interface ServiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  professionals: any[];
}

interface ServiceFormData {
  name: string;
  description?: string;
  price: number;
  duration: number;
  color?: string;
  professionalIds: string[];
}

export default function ServiceModal({ isOpen, onClose, professionals }: ServiceModalProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [selectedProfessionals, setSelectedProfessionals] = useState<string[]>([]);
  const router = useRouter();
  
  const { register, handleSubmit, reset, formState: { errors } } = useForm<ServiceFormData>();

  const onSubmit = async (data: ServiceFormData) => {
    setIsLoading(true);
    try {
      const formData = {
        ...data,
        price: Number(data.price),
        duration: Number(data.duration),
        professionalIds: selectedProfessionals
      };

      const response = await fetch('/api/services', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error('Erro ao criar serviço');
      }

      toast.success('Serviço cadastrado com sucesso!');
      reset();
      setSelectedProfessionals([]);
      onClose();
      router.refresh();
    } catch (error) {
      console.error('Error creating service:', error);
      toast.error('Erro ao cadastrar serviço. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    reset();
    setSelectedProfessionals([]);
    onClose();
  };

  const handleProfessionalToggle = (professionalId: string) => {
    setSelectedProfessionals(prev => {
      const newSelection = prev.includes(professionalId)
        ? prev.filter(id => id !== professionalId)
        : [...prev, professionalId];
      return newSelection;
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] flex flex-col">
        <DialogHeader className="shrink-0">
          <DialogTitle className="flex items-center space-x-2">
            <Briefcase className="w-5 h-5 text-blue-600" />
            <span>Cadastrar Novo Serviço</span>
          </DialogTitle>
        </DialogHeader>
        
        <div className="flex-1 overflow-y-auto px-1">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 pb-4">
            {/* Basic Information */}
            <div className="space-y-4">
              <h3 className="font-medium text-gray-900">Informações Básicas</h3>
              
              <div>
                <Label htmlFor="name" className="flex items-center space-x-1">
                  <Briefcase className="w-4 h-4" />
                  <span>Nome do Serviço *</span>
                </Label>
                <Input
                  id="name"
                  {...register('name', { required: 'Nome é obrigatório' })}
                  placeholder="Ex: Corte de cabelo masculino"
                />
                {errors.name && (
                  <span className="text-sm text-red-500">{errors.name.message}</span>
                )}
              </div>
              
              <div>
                <Label htmlFor="description" className="flex items-center space-x-1">
                  <FileText className="w-4 h-4" />
                  <span>Descrição</span>
                </Label>
                <Textarea
                  id="description"
                  {...register('description')}
                  placeholder="Descrição detalhada do serviço (opcional)"
                  rows={2}
                />
              </div>
              
              <div>
                <Label htmlFor="color">Cor (opcional)</Label>
                <Input
                  id="color"
                  type="color"
                  {...register('color')}
                />
              </div>
            </div>

            {/* Pricing and Duration */}
            <div className="space-y-4">
              <h3 className="font-medium text-gray-900">Preço e Duração</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="price" className="flex items-center space-x-1">
                    <DollarSign className="w-4 h-4" />
                    <span>Preço (R$) *</span>
                  </Label>
                  <Input
                    id="price"
                    type="number"
                    step="0.01"
                    min="0"
                    {...register('price', { 
                      required: 'Preço é obrigatório',
                      min: { value: 0, message: 'Preço deve ser positivo' }
                    })}
                    placeholder="0.00"
                  />
                  {errors.price && (
                    <span className="text-sm text-red-500">{errors.price.message}</span>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="duration" className="flex items-center space-x-1">
                    <Clock className="w-4 h-4" />
                    <span>Duração (minutos) *</span>
                  </Label>
                  <Input
                    id="duration"
                    type="number"
                    min="5"
                    step="5"
                    {...register('duration', { 
                      required: 'Duração é obrigatória',
                      min: { value: 5, message: 'Duração mínima é 5 minutos' }
                    })}
                    placeholder="30"
                  />
                  {errors.duration && (
                    <span className="text-sm text-red-500">{errors.duration.message}</span>
                  )}
                </div>
              </div>
            </div>

            {/* Professional Assignment */}
            <div className="space-y-3">
              <h3 className="font-medium text-gray-900">Profissionais Habilitados</h3>
              <p className="text-sm text-gray-600">
                Selecione os profissionais que podem realizar este serviço:
              </p>
              
              <div className="space-y-2 max-h-32 overflow-y-auto border rounded-lg p-3">
                {professionals?.filter(prof => prof.isActive).map((professional) => (
                  <div key={professional.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`prof-${professional.id}`}
                      checked={selectedProfessionals.includes(professional.id)}
                      onCheckedChange={() => handleProfessionalToggle(professional.id)}
                    />
                    <label 
                      htmlFor={`prof-${professional.id}`}
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer flex-1"
                    >
                      {professional.name}
                      <span className="text-gray-500 ml-1 block text-xs">
                        ({professional.specialties?.join(', ') || 'Sem especialidade'})
                      </span>
                    </label>
                  </div>
                )) || []}
                
                {!professionals?.filter(prof => prof.isActive).length && (
                  <p className="text-sm text-gray-500 italic">
                    Nenhum profissional ativo encontrado. Cadastre profissionais primeiro.
                  </p>
                )}
              </div>
            </div>

            {/* Summary */}
            <div className="bg-blue-50 p-3 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2">Resumo</h4>
              <div className="text-sm text-blue-800 space-y-1">
                <p>• Serviço disponível para agendamento</p>
                <p>• Visível na lista de serviços</p>
                <p>• Editável a qualquer momento</p>
              </div>
            </div>
          </form>
        </div>

        {/* Fixed footer with buttons */}
        <div className="shrink-0 border-t pt-4 mt-4">
          <div className="flex justify-end space-x-3">
            <Button type="button" variant="outline" onClick={handleClose} disabled={isLoading}>
              Cancelar
            </Button>
            <Button 
              type="submit" 
              disabled={isLoading} 
              className="bg-blue-600 hover:bg-blue-700"
              onClick={handleSubmit(onSubmit)}
            >
              {isLoading ? 'Cadastrando...' : 'Cadastrar Serviço'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
