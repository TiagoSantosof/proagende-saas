
import { withAuth } from 'next-auth/middleware';
import { NextResponse } from 'next/server';

export default withAuth(
  async function middleware(req) {
    const token = req.nextauth.token;
    
    // Se não há token, deixa o withAuth lidar com isso
    if (!token) return;

    // Verificar se é uma rota protegida do dashboard
    const isDashboardRoute = req.nextUrl.pathname.startsWith('/dashboard');
    
    if (isDashboardRoute && token.role === 'OWNER') {
      // NOTA: A verificação de assinatura agora é feita no lado do cliente
      // ou através de API routes para evitar problemas com Edge Runtime
      // O middleware apenas permite o acesso às rotas protegidas
      console.log('Acesso ao dashboard permitido para proprietário:', token.sub);
    }
    
    return NextResponse.next();
  },
  {
    callbacks: {
      authorized: ({ token }) => !!token,
    },
  }
);

export const config = {
  matcher: [
    '/dashboard/:path*',
    '/api/dashboard/:path*',
    '/api/appointments/:path*',
    '/api/professionals/:path*',
    '/api/services/:path*',
  ]
};
