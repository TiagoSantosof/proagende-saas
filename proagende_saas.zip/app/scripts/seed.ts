
import { PrismaClient, UserRole, SubscriptionStatus, SubscriptionPlan, AppointmentStatus } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Iniciando seed do banco de dados...');

  // Limpar dados existentes (ordem importante devido aos relacionamentos)
  await prisma.appointment.deleteMany();
  await prisma.service.deleteMany();
  await prisma.professional.deleteMany();
  await prisma.user.deleteMany();
  await prisma.tenant.deleteMany();
  
  console.log('🗑️  Dados antigos removidos');

  // Hash da senha padrão
  const hashedPassword = await bcrypt.hash('123456', 12);
  const adminPassword = await bcrypt.hash('admin123', 12);

  // 1. Criar usuário proprietário (conta de teste obrigatória)
  const adminUser = await prisma.user.create({
    data: {
      name: 'João Silva',
      email: 'john@doe.com', // Conta de teste obrigatória
      password: await bcrypt.hash('johndoe123', 12),
      phone: '(11) 99999-9999',
      role: UserRole.OWNER,
    }
  });

  // 2. Criar usuário proprietário principal
  const ownerUser = await prisma.user.create({
    data: {
      name: 'Maria Santos',
      email: 'maria@salaobeleza.com',
      password: adminPassword,
      phone: '(11) 98765-4321',
      role: UserRole.OWNER,
    }
  });

  // 3. Criar tenant (estabelecimento)
  const tenant = await prisma.tenant.create({
    data: {
      name: 'Salão Beleza & Estilo',
      slug: 'salao-beleza-estilo',
      email: 'contato@salaobeleza.com',
      phone: '(11) 3456-7890',
      address: 'Rua das Flores, 123',
      city: 'São Paulo',
      state: 'SP',
      description: 'Salão de beleza completo com profissionais especializados',
      subscriptionStatus: SubscriptionStatus.ACTIVE,
      subscriptionPlan: SubscriptionPlan.MONTHLY,
      subscriptionEndsAt: new Date(new Date().setMonth(new Date().getMonth() + 1)),
      ownerId: ownerUser.id,
    }
  });

  // 4. Criar clientes
  const customers = await Promise.all([
    prisma.user.create({
      data: {
        name: 'Ana Costa',
        email: 'ana@gmail.com',
        password: hashedPassword,
        phone: '(11) 91234-5678',
        role: UserRole.CUSTOMER,
        tenantId: tenant.id,
      }
    }),
    prisma.user.create({
      data: {
        name: 'Carlos Oliveira',
        email: 'carlos@gmail.com',
        password: hashedPassword,
        phone: '(11) 92345-6789',
        role: UserRole.CUSTOMER,
        tenantId: tenant.id,
      }
    }),
    prisma.user.create({
      data: {
        name: 'Beatriz Lima',
        email: 'beatriz@gmail.com',
        password: hashedPassword,
        phone: '(11) 93456-7890',
        role: UserRole.CUSTOMER,
        tenantId: tenant.id,
      }
    })
  ]);

  console.log('👥 Usuários criados');

  // 5. Criar profissionais
  const professionals = await Promise.all([
    prisma.professional.create({
      data: {
        name: 'Jessica Ferreira',
        email: 'jessica@salaobeleza.com',
        phone: '(11) 94567-8901',
        specialties: ['Corte', 'Coloração', 'Escova'],
        tenantId: tenant.id,
      }
    }),
    prisma.professional.create({
      data: {
        name: 'Roberto Silva',
        email: 'roberto@salaobeleza.com',
        phone: '(11) 95678-9012',
        specialties: ['Corte Masculino', 'Barba', 'Sobrancelha'],
        tenantId: tenant.id,
      }
    }),
    prisma.professional.create({
      data: {
        name: 'Camila Rodrigues',
        email: 'camila@salaobeleza.com',
        phone: '(11) 96789-0123',
        specialties: ['Manicure', 'Pedicure', 'Nail Art'],
        tenantId: tenant.id,
      }
    })
  ]);

  console.log('💼 Profissionais criados');

  // 6. Criar serviços
  const services = await Promise.all([
    // Serviços de cabelo
    prisma.service.create({
      data: {
        name: 'Corte Feminino',
        description: 'Corte de cabelo feminino com lavagem e finalização',
        duration: 60,
        price: 45.0,
        color: '#FF6B6B',
        tenantId: tenant.id,
        professionals: {
          connect: [{ id: professionals[0].id }]
        }
      }
    }),
    prisma.service.create({
      data: {
        name: 'Coloração',
        description: 'Coloração completa com produtos de qualidade',
        duration: 120,
        price: 80.0,
        color: '#4ECDC4',
        tenantId: tenant.id,
        professionals: {
          connect: [{ id: professionals[0].id }]
        }
      }
    }),
    prisma.service.create({
      data: {
        name: 'Escova Progressiva',
        description: 'Tratamento alisante com escova progressiva',
        duration: 180,
        price: 120.0,
        color: '#45B7D1',
        tenantId: tenant.id,
        professionals: {
          connect: [{ id: professionals[0].id }]
        }
      }
    }),
    // Serviços masculinos
    prisma.service.create({
      data: {
        name: 'Corte Masculino',
        description: 'Corte de cabelo masculino tradicional ou moderno',
        duration: 30,
        price: 25.0,
        color: '#96CEB4',
        tenantId: tenant.id,
        professionals: {
          connect: [{ id: professionals[1].id }]
        }
      }
    }),
    prisma.service.create({
      data: {
        name: 'Barba',
        description: 'Aparar e modelar barba com navalha',
        duration: 30,
        price: 20.0,
        color: '#FECA57',
        tenantId: tenant.id,
        professionals: {
          connect: [{ id: professionals[1].id }]
        }
      }
    }),
    // Serviços de estética
    prisma.service.create({
      data: {
        name: 'Manicure',
        description: 'Cuidados completos para as unhas das mãos',
        duration: 45,
        price: 15.0,
        color: '#FF9FF3',
        tenantId: tenant.id,
        professionals: {
          connect: [{ id: professionals[2].id }]
        }
      }
    }),
    prisma.service.create({
      data: {
        name: 'Pedicure',
        description: 'Cuidados completos para as unhas dos pés',
        duration: 60,
        price: 20.0,
        color: '#54A0FF',
        tenantId: tenant.id,
        professionals: {
          connect: [{ id: professionals[2].id }]
        }
      }
    })
  ]);

  console.log('💅 Serviços criados');

  // 7. Criar agendamentos (próximos dias)
  const now = new Date();
  const appointments = await Promise.all([
    // Hoje
    prisma.appointment.create({
      data: {
        date: new Date(now.getFullYear(), now.getMonth(), now.getDate(), 9, 0),
        duration: 60,
        status: AppointmentStatus.SCHEDULED,
        notes: 'Cliente prefere corte mais curto',
        totalAmount: 45.0,
        tenantId: tenant.id,
        customerId: customers[0].id,
        professionalId: professionals[0].id,
        serviceId: services[0].id,
      }
    }),
    prisma.appointment.create({
      data: {
        date: new Date(now.getFullYear(), now.getMonth(), now.getDate(), 14, 30),
        duration: 30,
        status: AppointmentStatus.CONFIRMED,
        totalAmount: 25.0,
        tenantId: tenant.id,
        customerId: customers[1].id,
        professionalId: professionals[1].id,
        serviceId: services[3].id,
      }
    }),
    // Amanhã
    prisma.appointment.create({
      data: {
        date: new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 10, 0),
        duration: 120,
        status: AppointmentStatus.SCHEDULED,
        notes: 'Primeira coloração da cliente',
        totalAmount: 80.0,
        tenantId: tenant.id,
        customerId: customers[2].id,
        professionalId: professionals[0].id,
        serviceId: services[1].id,
      }
    }),
    prisma.appointment.create({
      data: {
        date: new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 16, 0),
        duration: 45,
        status: AppointmentStatus.SCHEDULED,
        totalAmount: 15.0,
        tenantId: tenant.id,
        customerId: customers[0].id,
        professionalId: professionals[2].id,
        serviceId: services[5].id,
      }
    }),
    // Próxima semana
    prisma.appointment.create({
      data: {
        date: new Date(now.getFullYear(), now.getMonth(), now.getDate() + 7, 11, 0),
        duration: 180,
        status: AppointmentStatus.SCHEDULED,
        notes: 'Agendamento para evento especial',
        totalAmount: 120.0,
        tenantId: tenant.id,
        customerId: customers[1].id,
        professionalId: professionals[0].id,
        serviceId: services[2].id,
      }
    })
  ]);

  console.log('📅 Agendamentos criados');

  // Estatísticas finais
  const stats = {
    usuarios: await prisma.user.count(),
    tenants: await prisma.tenant.count(),
    profissionais: await prisma.professional.count(),
    servicos: await prisma.service.count(),
    agendamentos: await prisma.appointment.count(),
  };

  console.log('\n✅ Seed completado com sucesso!');
  console.log('📊 Estatísticas:');
  console.log(`   • ${stats.usuarios} usuários`);
  console.log(`   • ${stats.tenants} estabelecimentos`);
  console.log(`   • ${stats.profissionais} profissionais`);
  console.log(`   • ${stats.servicos} serviços`);
  console.log(`   • ${stats.agendamentos} agendamentos`);
  
  console.log('\n🔑 Contas de teste:');
  console.log('   • Admin: john@doe.com / johndoe123');
  console.log('   • Proprietário: maria@salaobeleza.com / admin123');
  console.log('   • Cliente: ana@gmail.com / 123456');
}

main()
  .then(async () => {
    await prisma.$disconnect();
  })
  .catch(async (e) => {
    console.error('❌ Erro no seed:', e);
    await prisma.$disconnect();
    process.exit(1);
  });
