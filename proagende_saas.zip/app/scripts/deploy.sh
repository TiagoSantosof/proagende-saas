
#!/bin/bash

echo "🚀 Iniciando deploy do ProAgenda SaaS..."

# Verificar se git está configurado
if ! command -v git &> /dev/null; then
    echo "❌ Git não está instalado"
    exit 1
fi

# Build da aplicação
echo "📦 Building aplicação..."
cd app
yarn build

if [ $? -eq 0 ]; then
    echo "✅ Build concluído com sucesso!"
else
    echo "❌ Erro no build"
    exit 1
fi

echo "🎉 Aplicação pronta para deploy!"
echo "📝 Próximos passos:"
echo "   1. Faça push do código para o GitHub"
echo "   2. Conecte o repositório na Vercel"
echo "   3. Configure as variáveis de ambiente"
echo "   4. Configure seu domínio personalizado"

cd ..
