
'use client';

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Calendar, 
  Check, 
  ArrowLeft, 
  Crown,
  Loader2,
  AlertCircle
} from 'lucide-react';

export default function PlansPage() {
  const { data: session, status } = useSession() || {};
  const router = useRouter();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const plans = [
    {
      id: 'monthly',
      name: 'Mensal',
      price: 'R$ 89',
      period: '/mês',
      originalPrice: null,
      discount: null,
      popular: false,
      checkoutUrl: 'https://pay.kiwify.com.br/UQA4Ci5',
      features: [
        'Agendamentos ilimitados',
        'Até 5 profissionais',
        'Calendário online',
        'Relatórios básicos',
        'Suporte por email',
        'App responsivo'
      ]
    },
    {
      id: 'quarterly',
      name: 'Trimestral',
      price: 'R$ 199',
      period: '/trimestre',
      originalPrice: 'R$ 267',
      discount: '25% OFF',
      popular: true,
      checkoutUrl: 'https://pay.kiwify.com.br/VRRAbUC',
      features: [
        'Todos os recursos do Mensal',
        'Até 10 profissionais',
        'Relatórios avançados',
        'Suporte prioritário',
        'Integração com WhatsApp',
        'Backup automático'
      ]
    },
    {
      id: 'annual',
      name: 'Anual',
      price: '10x R$ 69,90',
      period: '',
      originalPrice: 'R$ 1.068',
      discount: '35% OFF',
      popular: false,
      checkoutUrl: 'https://pay.kiwify.com.br/rSp1Joc',
      features: [
        'Todos os recursos do Trimestral',
        'Profissionais ilimitados',
        'API personalizada',
        'Suporte 24/7',
        'Treinamento dedicado',
        'Customizações exclusivas'
      ]
    }
  ];

  if (!mounted) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (status === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="border-b bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/" className="flex items-center space-x-2">
              <div className="bg-blue-600 p-2 rounded-lg">
                <Calendar className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">ProAgenda</span>
            </Link>
            
            <div className="flex items-center space-x-4">
              {session ? (
                <Button 
                  variant="ghost"
                  onClick={() => router.push('/dashboard')}
                >
                  Dashboard
                </Button>
              ) : (
                <div className="flex items-center space-x-2">
                  <Link href="/auth/login">
                    <Button variant="ghost">Entrar</Button>
                  </Link>
                  <Link href="/auth/register">
                    <Button variant="outline">Criar Conta</Button>
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        {/* Alert for logged users without plan */}
        {session && session.user?.role === 'OWNER' && (
          <Card className="border-orange-200 mb-8">
            <CardContent className="pt-4">
              <div className="flex items-center space-x-3">
                <div className="bg-orange-100 p-2 rounded-full">
                  <AlertCircle className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <p className="font-medium text-orange-900">
                    Plano Necessário
                  </p>
                  <p className="text-sm text-orange-700">
                    Você precisa escolher um plano para acessar todos os recursos do sistema.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="text-center mb-16">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Escolha o Plano Ideal
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Selecione o plano que melhor se adapta ao seu negócio. 
            Todos incluem suporte e atualizações gratuitas.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <Card 
              key={index} 
              className={`relative ${plan.popular ? 'border-2 border-blue-500 shadow-2xl scale-105' : 'border shadow-lg'}`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-blue-600 text-white px-4 py-1">
                    <Crown className="w-4 h-4 mr-1" />
                    Mais Popular
                  </Badge>
                </div>
              )}
              
              <CardHeader className="text-center pb-6">
                <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
                <div className="mt-4">
                  {plan.discount && (
                    <div className="mb-2">
                      <Badge variant="destructive" className="text-xs">
                        {plan.discount}
                      </Badge>
                      <p className="text-sm text-gray-500 line-through mt-1">
                        {plan.originalPrice}
                      </p>
                    </div>
                  )}
                  <div className="flex items-baseline justify-center">
                    <span className="text-4xl font-bold text-gray-900">{plan.price}</span>
                    <span className="text-gray-500 ml-1">{plan.period}</span>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                      <span className="text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Link 
                  href={plan.checkoutUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button 
                    className={`w-full ${
                      plan.popular 
                        ? 'bg-blue-600 hover:bg-blue-700' 
                        : 'bg-gray-900 hover:bg-gray-800'
                    }`}
                    size="lg"
                  >
                    Escolher Plano
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Back to home for non-logged users */}
        {!session && (
          <div className="text-center mt-12">
            <p className="text-gray-600 mb-4">
              Ainda não tem uma conta?
            </p>
            <Link href="/auth/register">
              <Button variant="outline" size="lg">
                Criar Conta Grátis
              </Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
