
import { Metadata } from 'next';
import LoginForm from './_components/login-form';
import Link from 'next/link';
import { Calendar, Sparkles } from 'lucide-react';

export const metadata: Metadata = {
  title: 'Login - ProAgenda',
  description: 'Faça login na sua conta ProAgenda',
};

export default function LoginPage() {
  return (
    <div className="min-h-screen flex">
      {/* Left side - Login Form */}
      <div className="flex-1 flex items-center justify-center px-4 sm:px-6 lg:px-8 bg-white">
        <div className="w-full max-w-md space-y-8">
          <div className="text-center">
            <div className="flex justify-center">
              <div className="flex items-center space-x-2">
                <div className="bg-blue-600 p-2 rounded-lg">
                  <Calendar className="w-6 h-6 text-white" />
                </div>
                <span className="text-2xl font-bold text-gray-900">ProAgenda</span>
              </div>
            </div>
            <h2 className="mt-6 text-3xl font-bold text-gray-900">
              Bem-vindo de volta
            </h2>
            <p className="mt-2 text-sm text-gray-600">
              Acesse sua conta para gerenciar seus agendamentos
            </p>
          </div>

          <LoginForm />

          <div className="text-center">
            <p className="text-sm text-gray-600">
              Não tem uma conta?{' '}
              <Link
                href="/auth/register"
                className="font-medium text-blue-600 hover:text-blue-500 transition-colors"
              >
                Cadastre-se gratuitamente
              </Link>
            </p>
          </div>
        </div>
      </div>

      {/* Right side - Hero */}
      <div className="hidden lg:flex lg:flex-1 lg:items-center lg:justify-center bg-gradient-to-br from-blue-600 via-purple-600 to-blue-800">
        <div className="text-center text-white max-w-md px-8">
          <div className="flex justify-center mb-8">
            <Sparkles className="w-16 h-16 text-blue-200" />
          </div>
          <h3 className="text-3xl font-bold mb-4">
            Gerencie seus agendamentos
          </h3>
          <p className="text-lg text-blue-100 mb-8">
            Plataforma completa para profissionais organizarem sua agenda e 
            oferecerem a melhor experiência aos clientes.
          </p>
          <div className="grid grid-cols-1 gap-4 text-sm">
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 bg-blue-300 rounded-full"></div>
              <span>Calendário intuitivo</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 bg-blue-300 rounded-full"></div>
              <span>Gestão de profissionais</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 bg-blue-300 rounded-full"></div>
              <span>Agendamentos online</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
