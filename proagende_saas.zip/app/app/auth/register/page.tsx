
import { Metadata } from 'next';
import RegisterForm from './_components/register-form';
import Link from 'next/link';
import { Calendar, Users, Clock, BarChart3 } from 'lucide-react';
import { Suspense } from 'react';

export const metadata: Metadata = {
  title: 'Cadastro - ProAgenda',
  description: 'Crie sua conta ProAgenda e comece a organizar seus agendamentos',
};

export default function RegisterPage() {
  return (
    <div className="min-h-screen flex">
      {/* Left side - Hero */}
      <div className="hidden lg:flex lg:flex-1 lg:items-center lg:justify-center bg-gradient-to-br from-purple-600 via-blue-600 to-indigo-800">
        <div className="text-center text-white max-w-lg px-8">
          <div className="flex justify-center mb-8">
            <div className="bg-white/10 p-4 rounded-2xl">
              <Calendar className="w-12 h-12 text-white" />
            </div>
          </div>
          <h2 className="text-4xl font-bold mb-6">
            Transforme seu negócio
          </h2>
          <p className="text-xl text-blue-100 mb-12">
            Sistema completo para gestão de agendamentos profissionais. 
            Organize, gerencie e cresça com facilidade.
          </p>
          
          <div className="grid grid-cols-2 gap-8">
            <div className="text-center">
              <div className="bg-white/10 p-3 rounded-xl w-fit mx-auto mb-3">
                <Users className="w-8 h-8 text-blue-200" />
              </div>
              <h4 className="font-semibold mb-2">Multi-profissional</h4>
              <p className="text-sm text-blue-100">Gerencie toda sua equipe</p>
            </div>
            <div className="text-center">
              <div className="bg-white/10 p-3 rounded-xl w-fit mx-auto mb-3">
                <Clock className="w-8 h-8 text-blue-200" />
              </div>
              <h4 className="font-semibold mb-2">24/7 Online</h4>
              <p className="text-sm text-blue-100">Agendamentos a qualquer hora</p>
            </div>
            <div className="text-center">
              <div className="bg-white/10 p-3 rounded-xl w-fit mx-auto mb-3">
                <BarChart3 className="w-8 h-8 text-blue-200" />
              </div>
              <h4 className="font-semibold mb-2">Relatórios</h4>
              <p className="text-sm text-blue-100">Acompanhe seu crescimento</p>
            </div>
            <div className="text-center">
              <div className="bg-white/10 p-3 rounded-xl w-fit mx-auto mb-3">
                <Calendar className="w-8 h-8 text-blue-200" />
              </div>
              <h4 className="font-semibold mb-2">Calendário</h4>
              <p className="text-sm text-blue-100">Interface intuitiva</p>
            </div>
          </div>
        </div>
      </div>

      {/* Right side - Register Form */}
      <div className="flex-1 flex items-center justify-center px-4 sm:px-6 lg:px-8 bg-white">
        <div className="w-full max-w-md space-y-8">
          <div className="text-center">
            <div className="flex justify-center">
              <div className="flex items-center space-x-2">
                <div className="bg-blue-600 p-2 rounded-lg">
                  <Calendar className="w-6 h-6 text-white" />
                </div>
                <span className="text-2xl font-bold text-gray-900">ProAgenda</span>
              </div>
            </div>
            <h2 className="mt-6 text-3xl font-bold text-gray-900">
              Crie sua conta
            </h2>
            <p className="mt-2 text-sm text-gray-600">
              Comece gratuitamente e transforme seu negócio
            </p>
          </div>

          <Suspense fallback={<div className="h-96 animate-pulse bg-gray-200 rounded-lg" />}>
            <RegisterForm />
          </Suspense>

          <div className="text-center">
            <p className="text-sm text-gray-600">
              Já tem uma conta?{' '}
              <Link
                href="/auth/login"
                className="font-medium text-blue-600 hover:text-blue-500 transition-colors"
              >
                Faça login
              </Link>
            </p>
          </div>

          <div className="text-center pt-4">
            <p className="text-xs text-gray-500">
              Ao criar uma conta, você aceita nossos{' '}
              <a href="#" className="text-blue-600 hover:text-blue-500">
                Termos de Uso
              </a>{' '}
              e{' '}
              <a href="#" className="text-blue-600 hover:text-blue-500">
                Política de Privacidade
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
