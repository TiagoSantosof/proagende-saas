
'use client';

import { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

import { Card, CardContent } from '@/components/ui/card';
import { Mail, Lock, User, Phone, Building2, Eye, EyeOff, Loader2, Crown, UserCheck, AlertCircle, CheckCircle2, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';
import { signIn } from 'next-auth/react';
import Link from 'next/link';

export default function RegisterForm() {
  const [mounted, setMounted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [purchaseData, setPurchaseData] = useState<any>(null);
  const [hasValidPurchase, setHasValidPurchase] = useState(false);
  const router = useRouter();
  const searchParams = useSearchParams();

  useEffect(() => {
    setMounted(true);
    
    // Verificar se há um token de compra válido ou se veio da página de sucesso
    const purchaseToken = searchParams.get('purchaseToken');
    const planParam = searchParams.get('plan');
    const fromSuccess = searchParams.get('fromSuccess');
    
    if (purchaseToken || fromSuccess || planParam) {
      const storedPurchase = localStorage.getItem('proagenda_purchase');
      if (storedPurchase) {
        try {
          const purchase = JSON.parse(storedPurchase);
          if (purchase.purchaseId === purchaseToken && purchase.status === 'completed') {
            setPurchaseData(purchase);
            setHasValidPurchase(true);
            return;
          }
        } catch (error) {
          console.error('Erro ao verificar compra:', error);
        }
      }
      
      // Se veio da página de sucesso ou tem parâmetro de plano, permitir registro
      if (fromSuccess || planParam) {
        setHasValidPurchase(true);
        setPurchaseData({
          planName: planParam || 'Plano Adquirido',
          status: 'completed'
        });
        return;
      }
    }
    
    // Permitir registro sempre (removendo restrição obrigatória)
    setHasValidPurchase(true);
  }, [searchParams]);

  // Owner form state
  const [ownerForm, setOwnerForm] = useState({
    name: '',
    email: '',
    phone: '',
    companyName: '',
    password: '',
    confirmPassword: '',
  });

  // Customer form state
  const [customerForm, setCustomerForm] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
  });

  const handleOwnerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const { name, email, phone, companyName, password, confirmPassword } = ownerForm;

    if (!name || !email || !companyName || !password) {
      toast.error('Por favor, preencha todos os campos obrigatórios');
      return;
    }

    if (password !== confirmPassword) {
      toast.error('As senhas não coincidem');
      return;
    }

    if (password.length < 6) {
      toast.error('A senha deve ter pelo menos 6 caracteres');
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch('/api/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          email,
          phone,
          companyName,
          password,
          isOwner: true,
          purchaseData: purchaseData,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        toast.error(data.error || 'Erro ao criar conta');
        return;
      }

      toast.success('Conta criada com sucesso!');
      
      // Se precisa de plano, redirecionar para a página de planos
      if (data.needsPlan) {
        // Auto login first
        const result = await signIn('credentials', {
          email,
          password,
          redirect: false,
        });

        if (result?.ok) {
          toast.info('Agora escolha seu plano para começar!');
          router.push('/plans');
        } else {
          router.push('/auth/login');
        }
        return;
      }
      
      // Auto login after registration
      const result = await signIn('credentials', {
        email,
        password,
        redirect: false,
      });

      if (result?.ok) {
        router.push('/dashboard');
      } else {
        router.push('/auth/login');
      }

    } catch (error) {
      toast.error('Erro inesperado. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCustomerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const { name, email, phone, password, confirmPassword } = customerForm;

    if (!name || !email || !password) {
      toast.error('Por favor, preencha todos os campos obrigatórios');
      return;
    }

    if (password !== confirmPassword) {
      toast.error('As senhas não coincidem');
      return;
    }

    if (password.length < 6) {
      toast.error('A senha deve ter pelo menos 6 caracteres');
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch('/api/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          email,
          phone,
          password,
          isOwner: false,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        toast.error(data.error || 'Erro ao criar conta');
        return;
      }

      toast.success('Conta criada com sucesso!');
      
      // Auto login after registration
      const result = await signIn('credentials', {
        email,
        password,
        redirect: false,
      });

      if (result?.ok) {
        router.push('/dashboard');
      } else {
        router.push('/auth/login');
      }

    } catch (error) {
      toast.error('Erro inesperado. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const [activeTab, setActiveTab] = useState<'owner' | 'customer'>('owner');

  if (!mounted) {
    return <div className="h-96 animate-pulse bg-gray-200 rounded-lg mt-8" />;
  }

  // Mensagem informativa se não veio de um plano específico
  const showPlanReminder = !purchaseData && activeTab === 'owner';

  return (
    <div className="mt-8">
      {/* Purchase Confirmation for Owner */}
      {purchaseData && (
        <Card className="border-green-200 mb-4">
          <CardContent className="pt-4">
            <div className="flex items-center space-x-3">
              <div className="bg-green-100 p-2 rounded-full">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="font-medium text-green-900">
                  Plano {purchaseData.planName} confirmado!
                </p>
                <p className="text-sm text-green-700">
                  Complete seu cadastro para acessar o sistema
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Aviso informativo para proprietários */}
      {showPlanReminder && (
        <Card className="border-blue-200 mb-4">
          <CardContent className="pt-4">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-100 p-2 rounded-full">
                <Crown className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="font-medium text-blue-900">
                  Conta de Proprietário
                </p>
                <p className="text-sm text-blue-700">
                  Lembre-se de adquirir um plano para acessar todos os recursos
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Custom Tab Buttons */}
      <div className="grid w-full grid-cols-2 gap-2 mb-4">
        <Button
          type="button"
          variant={activeTab === 'owner' ? 'default' : 'outline'}
          onClick={() => setActiveTab('owner')}
          className="flex items-center space-x-2"
        >
          <Crown className="w-4 h-4" />
          <span>Proprietário</span>
          {purchaseData && <ShieldCheck className="w-4 h-4 ml-1 text-green-500" />}
        </Button>
        <Button
          type="button"
          variant={activeTab === 'customer' ? 'default' : 'outline'}
          onClick={() => setActiveTab('customer')}
          className="flex items-center space-x-2"
        >
          <UserCheck className="w-4 h-4" />
          <span>Cliente</span>
        </Button>
      </div>

      {/* Tab Content */}
      {activeTab === 'owner' && (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center mb-6">
              <div className="bg-blue-100 p-3 rounded-full w-fit mx-auto mb-3">
                <Crown className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="font-semibold text-gray-900">Conta de Proprietário</h3>
              <p className="text-sm text-gray-600">Gerencie seu estabelecimento e profissionais</p>
            </div>

            <form onSubmit={handleOwnerSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="owner-name">Nome *</Label>
                    <div className="mt-1 relative">
                      <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        id="owner-name"
                        type="text"
                        required
                        value={ownerForm.name}
                        onChange={(e) => setOwnerForm({...ownerForm, name: e.target.value})}
                        className="pl-10"
                        placeholder="Seu nome"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="owner-phone">Telefone</Label>
                    <div className="mt-1 relative">
                      <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        id="owner-phone"
                        type="tel"
                        value={ownerForm.phone}
                        onChange={(e) => setOwnerForm({...ownerForm, phone: e.target.value})}
                        className="pl-10"
                        placeholder="(11) 99999-9999"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <Label htmlFor="owner-email">Email *</Label>
                  <div className="mt-1 relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      id="owner-email"
                      type="email"
                      required
                      value={ownerForm.email}
                      onChange={(e) => setOwnerForm({...ownerForm, email: e.target.value})}
                      className="pl-10"
                      placeholder="seu@email.com"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="company-name">Nome da Empresa *</Label>
                  <div className="mt-1 relative">
                    <Building2 className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      id="company-name"
                      type="text"
                      required
                      value={ownerForm.companyName}
                      onChange={(e) => setOwnerForm({...ownerForm, companyName: e.target.value})}
                      className="pl-10"
                      placeholder="Nome do seu estabelecimento"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="owner-password">Senha *</Label>
                    <div className="mt-1 relative">
                      <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        id="owner-password"
                        type={showPassword ? 'text' : 'password'}
                        required
                        value={ownerForm.password}
                        onChange={(e) => setOwnerForm({...ownerForm, password: e.target.value})}
                        className="pl-10 pr-10"
                        placeholder="Mínimo 6 caracteres"
                      />
                      <button
                        type="button"
                        className="absolute right-3 top-1/2 transform -translate-y-1/2"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4 text-gray-400" /> : <Eye className="h-4 w-4 text-gray-400" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="owner-confirm-password">Confirmar Senha *</Label>
                    <div className="mt-1 relative">
                      <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        id="owner-confirm-password"
                        type={showConfirmPassword ? 'text' : 'password'}
                        required
                        value={ownerForm.confirmPassword}
                        onChange={(e) => setOwnerForm({...ownerForm, confirmPassword: e.target.value})}
                        className="pl-10 pr-10"
                        placeholder="Confirme sua senha"
                      />
                      <button
                        type="button"
                        className="absolute right-3 top-1/2 transform -translate-y-1/2"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      >
                        {showConfirmPassword ? <EyeOff className="h-4 w-4 text-gray-400" /> : <Eye className="h-4 w-4 text-gray-400" />}
                      </button>
                    </div>
                  </div>
                </div>

              <Button
                type="submit"
                disabled={isLoading}
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Criar Conta de Proprietário'}
              </Button>
            </form>
          </CardContent>
        </Card>
      )}

      {activeTab === 'customer' && (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center mb-6">
              <div className="bg-green-100 p-3 rounded-full w-fit mx-auto mb-3">
                <UserCheck className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="font-semibold text-gray-900">Conta de Cliente</h3>
              <p className="text-sm text-gray-600">Agende serviços em estabelecimentos parceiros</p>
            </div>

            <form onSubmit={handleCustomerSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="customer-name">Nome *</Label>
                    <div className="mt-1 relative">
                      <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        id="customer-name"
                        type="text"
                        required
                        value={customerForm.name}
                        onChange={(e) => setCustomerForm({...customerForm, name: e.target.value})}
                        className="pl-10"
                        placeholder="Seu nome"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="customer-phone">Telefone</Label>
                    <div className="mt-1 relative">
                      <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        id="customer-phone"
                        type="tel"
                        value={customerForm.phone}
                        onChange={(e) => setCustomerForm({...customerForm, phone: e.target.value})}
                        className="pl-10"
                        placeholder="(11) 99999-9999"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <Label htmlFor="customer-email">Email *</Label>
                  <div className="mt-1 relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input
                      id="customer-email"
                      type="email"
                      required
                      value={customerForm.email}
                      onChange={(e) => setCustomerForm({...customerForm, email: e.target.value})}
                      className="pl-10"
                      placeholder="seu@email.com"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="customer-password">Senha *</Label>
                    <div className="mt-1 relative">
                      <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        id="customer-password"
                        type={showPassword ? 'text' : 'password'}
                        required
                        value={customerForm.password}
                        onChange={(e) => setCustomerForm({...customerForm, password: e.target.value})}
                        className="pl-10 pr-10"
                        placeholder="Mínimo 6 caracteres"
                      />
                      <button
                        type="button"
                        className="absolute right-3 top-1/2 transform -translate-y-1/2"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? <EyeOff className="h-4 w-4 text-gray-400" /> : <Eye className="h-4 w-4 text-gray-400" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="customer-confirm-password">Confirmar Senha *</Label>
                    <div className="mt-1 relative">
                      <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        id="customer-confirm-password"
                        type={showConfirmPassword ? 'text' : 'password'}
                        required
                        value={customerForm.confirmPassword}
                        onChange={(e) => setCustomerForm({...customerForm, confirmPassword: e.target.value})}
                        className="pl-10 pr-10"
                        placeholder="Confirme sua senha"
                      />
                      <button
                        type="button"
                        className="absolute right-3 top-1/2 transform -translate-y-1/2"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      >
                        {showConfirmPassword ? <EyeOff className="h-4 w-4 text-gray-400" /> : <Eye className="h-4 w-4 text-gray-400" />}
                      </button>
                    </div>
                  </div>
                </div>

              <Button
                type="submit"
                disabled={isLoading}
                className="w-full bg-green-600 hover:bg-green-700"
              >
                {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Criar Conta de Cliente'}
              </Button>
            </form>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
