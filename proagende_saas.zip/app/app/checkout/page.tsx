
'use client';

import { useEffect, useState, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Calendar, 
  Check, 
  ArrowLeft, 
  CreditCard, 
  Shield,
  Zap,
  Crown,
  Loader2
} from 'lucide-react';
import { toast } from 'sonner';

function CheckoutContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const [isProcessing, setIsProcessing] = useState(false);
  const [mounted, setMounted] = useState(false);

  const planParam = searchParams.get('plan');

  useEffect(() => {
    setMounted(true);
  }, []);

  const plans = {
    monthly: {
      name: 'Mensal',
      price: 'R$ 89',
      period: '/mês',
      originalPrice: null,
      discount: null,
      popular: false,
      value: 89.00,
      features: [
        'Agendamentos ilimitados',
        'Até 5 profissionais',
        'Calendário online',
        'Relatórios básicos',
        'Suporte por email',
        'App responsivo'
      ]
    },
    quarterly: {
      name: 'Trimestral',
      price: 'R$ 199',
      period: '/trimestre',
      originalPrice: 'R$ 267',
      discount: '25% OFF',
      popular: true,
      value: 199.00,
      features: [
        'Todos os recursos do Mensal',
        'Até 10 profissionais',
        'Relatórios avançados',
        'Suporte prioritário',
        'Integração com WhatsApp',
        'Backup automático'
      ]
    },
    annual: {
      name: 'Anual',
      price: '10x R$ 69,90',
      period: '',
      originalPrice: 'R$ 1.068',
      discount: '35% OFF',
      popular: false,
      value: 699.00,
      features: [
        'Todos os recursos do Trimestral',
        'Profissionais ilimitados',
        'API personalizada',
        'Suporte 24/7',
        'Treinamento dedicado',
        'Customizações exclusivas'
      ]
    }
  };

  const selectedPlan = planParam && plans[planParam as keyof typeof plans] ? plans[planParam as keyof typeof plans] : null;

  const handlePurchase = async () => {
    if (!selectedPlan) return;

    setIsProcessing(true);
    
    try {
      // Simular processamento de pagamento
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Salvar informações do plano no localStorage para verificação posterior
      const purchaseData = {
        plan: planParam,
        planName: selectedPlan.name,
        price: selectedPlan.value,
        purchaseDate: new Date().toISOString(),
        purchaseId: `PUR_${Date.now()}`,
        status: 'completed'
      };
      
      localStorage.setItem('proagenda_purchase', JSON.stringify(purchaseData));
      
      toast.success('Pagamento processado com sucesso!');
      
      // Redirecionar para o cadastro com token de compra
      setTimeout(() => {
        router.push(`/auth/register?purchaseToken=${purchaseData.purchaseId}&plan=${planParam}`);
      }, 1500);
      
    } catch (error) {
      toast.error('Erro no processamento do pagamento. Tente novamente.');
      setIsProcessing(false);
    }
  };

  if (!mounted) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (!selectedPlan) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="max-w-md mx-auto">
          <CardContent className="text-center py-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Plano não encontrado</h2>
            <p className="text-gray-600 mb-6">O plano selecionado não existe.</p>
            <Link href="/">
              <Button>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar ao início
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="border-b bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/" className="flex items-center space-x-2">
              <div className="bg-blue-600 p-2 rounded-lg">
                <Calendar className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">ProAgenda</span>
            </Link>
            <Link href="/">
              <Button variant="ghost">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Checkout Content */}
      <div className="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Finalizar Compra</h1>
          <p className="text-gray-600">Complete sua assinatura do ProAgenda</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Plan Summary */}
          <Card className={`${selectedPlan.popular ? 'border-2 border-blue-500' : ''}`}>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-2xl">{selectedPlan.name}</CardTitle>
                  {selectedPlan.popular && (
                    <Badge className="bg-blue-600 text-white mt-2">
                      <Crown className="w-4 h-4 mr-1" />
                      Mais Popular
                    </Badge>
                  )}
                </div>
                <div className="text-right">
                  {selectedPlan.discount && (
                    <div className="mb-2">
                      <Badge variant="destructive" className="text-xs">
                        {selectedPlan.discount}
                      </Badge>
                      <p className="text-sm text-gray-500 line-through mt-1">
                        {selectedPlan.originalPrice}
                      </p>
                    </div>
                  )}
                  <div className="flex items-baseline justify-end">
                    <span className="text-3xl font-bold text-gray-900">{selectedPlan.price}</span>
                    <span className="text-gray-500 ml-1">{selectedPlan.period}</span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {selectedPlan.features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                    <span className="text-gray-600">{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          {/* Payment Form */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CreditCard className="w-5 h-5 mr-2" />
                Informações de Pagamento
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <div className="flex items-center">
                  <Zap className="w-5 h-5 text-yellow-600 mr-2" />
                  <span className="text-sm font-medium text-yellow-800">
                    Demonstração - Pagamento Simulado
                  </span>
                </div>
                <p className="text-sm text-yellow-700 mt-1">
                  Este é um ambiente de demonstração. O pagamento será simulado.
                </p>
              </div>

              <div className="space-y-4">
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <Shield className="w-4 h-4" />
                  <span>Dados protegidos com criptografia SSL</span>
                </div>
                
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium text-gray-900 mb-2">Resumo da Compra</h4>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Plano {selectedPlan.name}</span>
                    <span className="font-semibold">{selectedPlan.price}{selectedPlan.period}</span>
                  </div>
                  {selectedPlan.discount && (
                    <div className="flex justify-between items-center text-green-600 text-sm mt-1">
                      <span>Desconto</span>
                      <span>{selectedPlan.discount}</span>
                    </div>
                  )}
                  <div className="border-t pt-2 mt-3 flex justify-between items-center font-bold">
                    <span>Total</span>
                    <span className="text-blue-600">{selectedPlan.price}</span>
                  </div>
                </div>
              </div>

              <Button 
                onClick={handlePurchase}
                disabled={isProcessing}
                className="w-full bg-blue-600 hover:bg-blue-700 text-lg py-3"
                size="lg"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Processando Pagamento...
                  </>
                ) : (
                  <>
                    <CreditCard className="w-5 h-5 mr-2" />
                    Confirmar Pagamento - {selectedPlan.price}
                  </>
                )}
              </Button>

              <div className="text-center text-sm text-gray-500">
                <p>Após a confirmação do pagamento, você será direcionado para criar sua conta.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

export default function CheckoutPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    }>
      <CheckoutContent />
    </Suspense>
  );
}
