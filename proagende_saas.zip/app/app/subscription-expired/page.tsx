
'use client';

import { useSession, signOut } from 'next-auth/react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertCircle, CreditCard } from 'lucide-react';
import Link from 'next/link';

export default function SubscriptionExpiredPage() {
  const { data: session } = useSession() || {};

  const handleSignOut = async () => {
    await signOut({ callbackUrl: '/' });
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
            <AlertCircle className="w-6 h-6 text-red-600" />
          </div>
          <CardTitle className="text-xl font-semibold text-gray-900">
            Assinatura Expirada
          </CardTitle>
          <CardDescription>
            Sua assinatura expirou. Renove seu plano para continuar usando o ProAgenda.
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <p className="text-sm text-yellow-800">
              <strong>Olá, {session?.user?.name}!</strong>
              <br />
              Para continuar gerenciando seus agendamentos, você precisa renovar seu plano.
            </p>
          </div>

          <div className="space-y-3">
            <Link href="/" className="w-full">
              <Button className="w-full" size="lg">
                <CreditCard className="w-4 h-4 mr-2" />
                Renovar Plano
              </Button>
            </Link>

            <Button
              variant="outline"
              size="lg"
              className="w-full"
              onClick={handleSignOut}
            >
              Sair da Conta
            </Button>
          </div>

          <div className="pt-4 border-t">
            <p className="text-xs text-gray-500 text-center">
              Dúvidas? Entre em contato conosco pelo email{' '}
              <a href="mailto:suporte@proagende.com" className="text-blue-600 hover:underline">
                suporte@proagende.com
              </a>
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
