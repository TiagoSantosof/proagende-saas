
'use client';

import { useEffect, useState, Suspense } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Calendar, ArrowRight, Crown, Sparkles } from 'lucide-react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';

function SuccessContent() {
  const searchParams = useSearchParams();
  const [plan, setPlan] = useState<string | null>(null);

  useEffect(() => {
    // Detectar plano baseado nos parâmetros da URL ou referrer
    const planParam = searchParams.get('plan');
    const referrer = document.referrer;
    
    if (planParam) {
      setPlan(planParam);
    } else if (referrer.includes('kiwify.com.br')) {
      // Detectar plano baseado no referrer da Kiwify
      if (referrer.includes('UQA4Ci5')) {
        setPlan('mensal');
      } else if (referrer.includes('VRRAbUC')) {
        setPlan('trimestral');
      } else if (referrer.includes('rSp1Joc')) {
        setPlan('anual');
      }
    }
  }, [searchParams]);

  const getPlanInfo = (planType: string | null) => {
    switch(planType) {
      case 'mensal':
        return {
          name: 'Plano Mensal',
          price: 'R$ 89/mês',
          color: 'bg-blue-500',
          features: ['Agendamentos ilimitados', 'Até 5 profissionais', 'Suporte por email']
        };
      case 'trimestral':
        return {
          name: 'Plano Trimestral',
          price: 'R$ 199/trimestre',
          color: 'bg-purple-500',
          features: ['Todos os recursos do Mensal', 'Até 10 profissionais', 'Suporte prioritário']
        };
      case 'anual':
        return {
          name: 'Plano Anual',
          price: '10x R$ 69,90',
          color: 'bg-green-500',
          features: ['Todos os recursos do Trimestral', 'Profissionais ilimitados', 'Suporte 24/7']
        };
      default:
        return {
          name: 'Seu Plano',
          price: '',
          color: 'bg-blue-500',
          features: ['Acesso completo ao sistema', 'Recursos premium', 'Suporte técnico']
        };
    }
  };

  const planInfo = getPlanInfo(plan);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50 flex items-center justify-center px-4">
      <div className="max-w-2xl w-full">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-6">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
              <CheckCircle className="w-12 h-12 text-green-600" />
            </div>
          </div>
          
          <div className="flex justify-center mb-4">
            <div className="flex items-center space-x-2 bg-green-100 px-4 py-2 rounded-full">
              <Sparkles className="w-5 h-5 text-green-600" />
              <span className="text-green-800 text-sm font-medium">Pagamento Confirmado!</span>
            </div>
          </div>

          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Bem-vindo ao ProAgenda! 🎉
          </h1>
          
          <p className="text-xl text-gray-600 mb-8">
            Seu pagamento foi processado com sucesso. Agora você pode criar sua conta e começar a usar todos os recursos.
          </p>
        </div>

        <Card className="mb-8 border-0 shadow-xl">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <Badge className={`${planInfo.color} text-white px-4 py-2`}>
                <Crown className="w-4 h-4 mr-2" />
                {planInfo.name}
              </Badge>
            </div>
            <CardTitle className="text-2xl">{planInfo.price}</CardTitle>
          </CardHeader>
          
          <CardContent>
            <div className="space-y-3 mb-6">
              {planInfo.features.map((feature, index) => (
                <div key={index} className="flex items-center">
                  <CheckCircle className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">{feature}</span>
                </div>
              ))}
            </div>

            <div className="bg-blue-50 p-4 rounded-lg mb-6">
              <h3 className="font-semibold text-blue-900 mb-2">Próximos Passos:</h3>
              <ul className="text-blue-800 text-sm space-y-1">
                <li>1. Crie sua conta usando o mesmo email do pagamento</li>
                <li>2. Configure seu estabelecimento e profissionais</li>
                <li>3. Comece a receber agendamentos online</li>
              </ul>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href={`/auth/register?fromSuccess=true&plan=${plan || 'adquirido'}`} className="flex-1">
                <Button className="w-full bg-blue-600 hover:bg-blue-700" size="lg">
                  <Calendar className="w-5 h-5 mr-2" />
                  Criar Minha Conta
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
              
              <Link href="/auth/login" className="flex-1">
                <Button variant="outline" className="w-full" size="lg">
                  Já tenho conta - Entrar
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        <div className="text-center">
          <p className="text-gray-500 text-sm">
            Precisa de ajuda? Entre em contato pelo nosso suporte.
          </p>
        </div>
      </div>
    </div>
  );
}

export default function SuccessPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50 flex items-center justify-center">
        <div className="animate-pulse">
          <div className="w-20 h-20 bg-green-200 rounded-full mx-auto mb-4"></div>
          <div className="h-4 bg-gray-200 rounded w-48 mx-auto mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-32 mx-auto"></div>
        </div>
      </div>
    }>
      <SuccessContent />
    </Suspense>
  );
}
