
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id || session.user.role !== 'OWNER') {
      return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
    }

    const {
      name,
      description,
      price,
      duration,
      color,
      professionalIds = [],
    } = await request.json();

    // Validação básica
    if (!name || price === undefined || !duration) {
      return NextResponse.json({ error: 'Campos obrigatórios não preenchidos' }, { status: 400 });
    }

    if (price < 0) {
      return NextResponse.json({ error: 'Preço deve ser maior ou igual a zero' }, { status: 400 });
    }

    if (duration < 5) {
      return NextResponse.json({ error: 'Duração mínima é 5 minutos' }, { status: 400 });
    }

    // Verificar se o usuário possui um tenant
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { ownedTenants: true }
    });

    if (!user?.ownedTenants?.[0]) {
      return NextResponse.json({ error: 'Estabelecimento não encontrado' }, { status: 404 });
    }

    const tenantId = user.ownedTenants[0].id;

    // Verificar se já existe um serviço com este nome no tenant
    const existingService = await prisma.service.findFirst({
      where: {
        name,
        tenantId
      }
    });

    if (existingService) {
      return NextResponse.json({ error: 'Já existe um serviço com este nome' }, { status: 409 });
    }

    // Verificar se os profissionais existem e pertencem ao tenant
    if (professionalIds.length > 0) {
      const professionalCount = await prisma.professional.count({
        where: {
          id: { in: professionalIds },
          tenantId
        }
      });

      if (professionalCount !== professionalIds.length) {
        return NextResponse.json({ error: 'Um ou mais profissionais não foram encontrados' }, { status: 404 });
      }
    }

    // Criar o serviço
    const service = await prisma.service.create({
      data: {
        name,
        description: description || undefined,
        price,
        duration,
        color: color || undefined,
        tenantId,
        professionals: professionalIds.length > 0 ? {
          connect: professionalIds.map((id: string) => ({ id }))
        } : undefined,
      },
      include: {
        professionals: true,
      }
    });

    return NextResponse.json(service, { status: 201 });

  } catch (error) {
    console.error('Error creating service:', error);
    return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
    }

    // Buscar os serviços do tenant do usuário
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: {
        ownedTenants: {
          include: {
            services: {
              include: {
                appointments: {
                  include: {
                    customer: true,
                    professional: true,
                  }
                },
                professionals: true,
              }
            }
          }
        }
      }
    });

    if (!user?.ownedTenants?.[0]) {
      return NextResponse.json({ error: 'Estabelecimento não encontrado' }, { status: 404 });
    }

    return NextResponse.json(user.ownedTenants[0].services);

  } catch (error) {
    console.error('Error fetching services:', error);
    return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 });
  }
}
