
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function PUT(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id || session.user.role !== 'OWNER') {
      return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
    }

    const body = await req.json();
    const {
      timezone,
      currency,
      language,
      workingDays,
      workingHours,
      appointmentDuration,
      advanceBookingDays
    } = body;

    // Get user's tenant
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: {
        ownedTenants: true
      }
    });

    if (!user?.ownedTenants?.[0]) {
      return NextResponse.json({ error: 'Estabelecimento não encontrado' }, { status: 404 });
    }

    const tenantId = user.ownedTenants[0].id;

    // For now, we'll just return success since settings field doesn't exist in current schema
    // In a real implementation, we would create a separate settings table
    
    // Simulate successful save (would normally save to database)
    console.log('Business settings saved:', {
      tenantId,
      timezone,
      currency,
      language,
      workingDays,
      workingHours,
      appointmentDuration,
      advanceBookingDays
    });

    return NextResponse.json({ 
      success: true, 
      message: 'Configurações do negócio atualizadas com sucesso!'
    });

  } catch (error) {
    console.error('Error updating business settings:', error);
    return NextResponse.json({ 
      error: 'Erro interno do servidor' 
    }, { status: 500 });
  }
}
