
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function PUT(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id || session.user.role !== 'OWNER') {
      return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
    }

    const body = await req.json();
    const { name, description, phone, email, address, website } = body;

    // Get user's tenant
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: {
        ownedTenants: true
      }
    });

    if (!user?.ownedTenants?.[0]) {
      return NextResponse.json({ error: 'Estabelecimento não encontrado' }, { status: 404 });
    }

    const tenantId = user.ownedTenants[0].id;

    // Update tenant information (only fields that exist in schema)
    const updatedTenant = await prisma.tenant.update({
      where: { id: tenantId },
      data: {
        name,
        description,
        phone,
        email,
        address
        // Note: website field doesn't exist in current schema
      }
    });

    return NextResponse.json({ 
      success: true, 
      tenant: updatedTenant,
      message: 'Configurações gerais atualizadas com sucesso!'
    });

  } catch (error) {
    console.error('Error updating general settings:', error);
    return NextResponse.json({ 
      error: 'Erro interno do servidor' 
    }, { status: 500 });
  }
}
