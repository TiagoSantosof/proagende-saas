
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { getUserSubscriptionInfo } from '@/lib/subscription';

export const dynamic = 'force-dynamic';

/**
 * API para verificar status da assinatura do usuário logado
 */
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Não autorizado' },
        { status: 401 }
      );
    }

    // Só proprietários têm assinatura
    if (session.user.role !== 'OWNER') {
      return NextResponse.json(
        { error: 'Apenas proprietários possuem assinatura' },
        { status: 403 }
      );
    }

    const subscriptionInfo = await getUserSubscriptionInfo(session.user.id);
    
    if (!subscriptionInfo) {
      return NextResponse.json(
        { error: 'Assinatura não encontrada' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      subscription: subscriptionInfo,
      message: subscriptionInfo.isActive 
        ? 'Assinatura ativa' 
        : 'Assinatura expirada ou inativa'
    });

  } catch (error) {
    console.error('Erro ao verificar assinatura:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
