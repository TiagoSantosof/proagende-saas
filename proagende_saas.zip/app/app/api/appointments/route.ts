
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id || session.user.role !== 'OWNER') {
      return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
    }

    const {
      customerName,
      customerEmail,
      customerPhone,
      professionalId,
      serviceId,
      date,
      notes,
    } = await request.json();

    // Validação básica
    if (!customerName || !customerPhone || !professionalId || !serviceId || !date) {
      return NextResponse.json({ error: 'Campos obrigatórios não preenchidos' }, { status: 400 });
    }

    // Verificar se o usuário possui um tenant
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { ownedTenants: true }
    });

    if (!user?.ownedTenants?.[0]) {
      return NextResponse.json({ error: 'Estabelecimento não encontrado' }, { status: 404 });
    }

    const tenantId = user.ownedTenants[0].id;

    // Verificar se o profissional e serviço pertencem ao tenant
    const professional = await prisma.professional.findFirst({
      where: { id: professionalId, tenantId }
    });

    const service = await prisma.service.findFirst({
      where: { id: serviceId, tenantId }
    });

    if (!professional || !service) {
      return NextResponse.json({ error: 'Profissional ou serviço não encontrado' }, { status: 404 });
    }

    // Verificar se já existe cliente com esse telefone ou email
    let customer = await prisma.user.findFirst({
      where: {
        OR: [
          { phone: customerPhone },
          { email: customerEmail }
        ]
      }
    });

    // Se não existe, criar novo cliente
    if (!customer) {
      customer = await prisma.user.create({
        data: {
          name: customerName,
          email: customerEmail || undefined,
          phone: customerPhone,
          role: 'CUSTOMER',
        }
      });
    }

    // Criar o agendamento
    const appointment = await prisma.appointment.create({
      data: {
        date: new Date(date),
        duration: service.duration, // Usar a duração do serviço
        totalAmount: service.price, // Usar o preço do serviço
        status: 'SCHEDULED',
        notes: notes || undefined,
        customerId: customer.id,
        professionalId,
        serviceId,
        tenantId,
      },
      include: {
        customer: true,
        professional: true,
        service: true,
      }
    });

    return NextResponse.json(appointment, { status: 201 });

  } catch (error) {
    console.error('Error creating appointment:', error);
    return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
    }

    // Buscar os agendamentos do tenant do usuário
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: {
        ownedTenants: {
          include: {
            appointments: {
              include: {
                customer: true,
                professional: true,
                service: true,
              },
              orderBy: {
                date: 'asc'
              }
            }
          }
        }
      }
    });

    if (!user?.ownedTenants?.[0]) {
      return NextResponse.json({ error: 'Estabelecimento não encontrado' }, { status: 404 });
    }

    return NextResponse.json(user.ownedTenants[0].appointments);

  } catch (error) {
    console.error('Error fetching appointments:', error);
    return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 });
  }
}
