
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id || session.user.role !== 'OWNER') {
      return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
    }

    // Get tenant data for owners
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: {
        ownedTenants: {
          include: {
            professionals: true,
            services: true,
            appointments: {
              include: {
                customer: true,
                professional: true,
                service: true,
              },
              orderBy: {
                date: 'desc'
              },
              take: 10
            },
            customers: true,
          }
        }
      }
    });

    if (!user?.ownedTenants?.[0]) {
      return NextResponse.json({ error: 'Estabelecimento não encontrado' }, { status: 404 });
    }

    const tenant = user.ownedTenants[0];
    
    // Calculate metrics with real-time data
    const today = new Date();
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const startOfLastMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1);
    const endOfLastMonth = new Date(today.getFullYear(), today.getMonth(), 0);
    
    // Monthly appointments count
    const monthlyAppointments = await prisma.appointment.count({
      where: {
        tenantId: tenant.id,
        date: {
          gte: startOfMonth
        }
      }
    });

    // Last month appointments for comparison
    const lastMonthAppointments = await prisma.appointment.count({
      where: {
        tenantId: tenant.id,
        date: {
          gte: startOfLastMonth,
          lte: endOfLastMonth
        }
      }
    });

    // Monthly revenue (completed appointments only)
    const monthlyRevenue = await prisma.appointment.aggregate({
      where: {
        tenantId: tenant.id,
        date: {
          gte: startOfMonth
        },
        status: 'COMPLETED'
      },
      _sum: {
        totalAmount: true
      }
    });

    // Last month revenue for comparison
    const lastMonthRevenue = await prisma.appointment.aggregate({
      where: {
        tenantId: tenant.id,
        date: {
          gte: startOfLastMonth,
          lte: endOfLastMonth
        },
        status: 'COMPLETED'
      },
      _sum: {
        totalAmount: true
      }
    });

    // Daily appointments for today
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date();
    endOfDay.setHours(23, 59, 59, 999);

    const todayAppointments = await prisma.appointment.count({
      where: {
        tenantId: tenant.id,
        date: {
          gte: startOfDay,
          lte: endOfDay
        }
      }
    });

    // Weekly appointments
    const startOfWeek = new Date();
    startOfWeek.setDate(today.getDate() - today.getDay());
    startOfWeek.setHours(0, 0, 0, 0);

    const weeklyAppointments = await prisma.appointment.count({
      where: {
        tenantId: tenant.id,
        date: {
          gte: startOfWeek
        }
      }
    });

    // Calculate growth percentages
    const appointmentGrowth = lastMonthAppointments > 0 
      ? ((monthlyAppointments - lastMonthAppointments) / lastMonthAppointments) * 100 
      : 0;

    const revenueGrowth = (lastMonthRevenue._sum.totalAmount || 0) > 0 
      ? (((monthlyRevenue._sum.totalAmount || 0) - (lastMonthRevenue._sum.totalAmount || 0)) / (lastMonthRevenue._sum.totalAmount || 0)) * 100 
      : 0;

    const stats = {
      totalProfessionals: tenant.professionals.length,
      totalServices: tenant.services.length,
      totalCustomers: tenant.customers.length,
      monthlyAppointments,
      lastMonthAppointments,
      monthlyRevenue: monthlyRevenue._sum.totalAmount || 0,
      lastMonthRevenue: lastMonthRevenue._sum.totalAmount || 0,
      todayAppointments,
      weeklyAppointments,
      appointmentGrowth: Math.round(appointmentGrowth * 100) / 100,
      revenueGrowth: Math.round(revenueGrowth * 100) / 100,
      recentAppointments: tenant.appointments,
      lastUpdated: new Date().toISOString()
    };

    return NextResponse.json({ 
      success: true, 
      stats 
    });

  } catch (error) {
    console.error('Error fetching dashboard stats:', error);
    return NextResponse.json({ 
      error: 'Erro interno do servidor' 
    }, { status: 500 });
  }
}
