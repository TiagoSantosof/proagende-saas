
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id || session.user.role !== 'OWNER') {
      return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
    }

    const {
      name,
      email,
      phone,
      specialties = [],
      workingHours = [],
    } = await request.json();

    // Validação básica
    if (!name || !email || !phone) {
      return NextResponse.json({ error: 'Campos obrigatórios não preenchidos' }, { status: 400 });
    }

    // Verificar se o usuário possui um tenant
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { ownedTenants: true }
    });

    if (!user?.ownedTenants?.[0]) {
      return NextResponse.json({ error: 'Estabelecimento não encontrado' }, { status: 404 });
    }

    const tenantId = user.ownedTenants[0].id;

    // Verificar se já existe um profissional com este email no tenant
    const existingProfessional = await prisma.professional.findFirst({
      where: {
        email,
        tenantId
      }
    });

    if (existingProfessional) {
      return NextResponse.json({ error: 'Já existe um profissional com este e-mail' }, { status: 409 });
    }

    // Criar o profissional com horários de trabalho
    const professional = await prisma.professional.create({
      data: {
        name,
        email,
        phone: phone || undefined,
        specialties,
        tenantId,
        workingHours: {
          create: workingHours.filter((wh: any) => wh.isWorkingDay).map((wh: any) => ({
            dayOfWeek: wh.dayOfWeek,
            isWorkingDay: wh.isWorkingDay,
            morningStart: wh.morningStart || null,
            morningEnd: wh.morningEnd || null,
            afternoonStart: wh.afternoonStart || null,
            afternoonEnd: wh.afternoonEnd || null,
          }))
        }
      },
      include: {
        workingHours: true
      }
    });

    return NextResponse.json(professional, { status: 201 });

  } catch (error) {
    console.error('Error creating professional:', error);
    return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
    }

    // Buscar os profissionais do tenant do usuário
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: {
        ownedTenants: {
          include: {
            professionals: {
              include: {
                appointments: {
                  include: {
                    customer: true,
                    service: true,
                  }
                },
                services: true,
                workingHours: true,
              }
            }
          }
        }
      }
    });

    if (!user?.ownedTenants?.[0]) {
      return NextResponse.json({ error: 'Estabelecimento não encontrado' }, { status: 404 });
    }

    return NextResponse.json(user.ownedTenants[0].professionals);

  } catch (error) {
    console.error('Error fetching professionals:', error);
    return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 });
  }
}
