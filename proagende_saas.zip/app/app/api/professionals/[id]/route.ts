
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
    }

    const professional = await prisma.professional.findUnique({
      where: { id: params.id },
      include: {
        workingHours: true,
        services: true,
        appointments: {
          include: {
            customer: true,
            service: true,
          }
        },
        tenant: true,
      }
    });

    if (!professional) {
      return NextResponse.json({ error: 'Profissional não encontrado' }, { status: 404 });
    }

    // Verificar se o usuário tem acesso a este profissional
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { ownedTenants: true }
    });

    const userTenantId = user?.ownedTenants?.[0]?.id;
    
    if (professional.tenantId !== userTenantId) {
      return NextResponse.json({ error: 'Acesso negado' }, { status: 403 });
    }

    return NextResponse.json(professional);

  } catch (error) {
    console.error('Error fetching professional:', error);
    return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id || session.user.role !== 'OWNER') {
      return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
    }

    const {
      name,
      phone,
      specialties = [],
      workingHours = [],
    } = await request.json();

    // Validação básica
    if (!name) {
      return NextResponse.json({ error: 'Nome é obrigatório' }, { status: 400 });
    }

    // Verificar se o profissional existe e se pertence ao tenant do usuário
    const existingProfessional = await prisma.professional.findUnique({
      where: { id: params.id },
      include: { tenant: true }
    });

    if (!existingProfessional) {
      return NextResponse.json({ error: 'Profissional não encontrado' }, { status: 404 });
    }

    // Verificar se o usuário possui um tenant
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { ownedTenants: true }
    });

    if (!user?.ownedTenants?.[0]) {
      return NextResponse.json({ error: 'Estabelecimento não encontrado' }, { status: 404 });
    }

    const userTenantId = user.ownedTenants[0].id;
    
    if (existingProfessional.tenantId !== userTenantId) {
      return NextResponse.json({ error: 'Acesso negado' }, { status: 403 });
    }

    // Atualizar o profissional
    const updatedProfessional = await prisma.$transaction(async (tx) => {
      // Primeiro, deletar horários de trabalho existentes
      await tx.workingHours.deleteMany({
        where: { professionalId: params.id }
      });

      // Atualizar os dados básicos do profissional
      const professional = await tx.professional.update({
        where: { id: params.id },
        data: {
          name,
          phone: phone || null,
          specialties,
        }
      });

      // Criar novos horários de trabalho
      if (workingHours.length > 0) {
        await tx.workingHours.createMany({
          data: workingHours.filter((wh: any) => wh.isWorkingDay).map((wh: any) => ({
            professionalId: params.id,
            dayOfWeek: wh.dayOfWeek,
            isWorkingDay: wh.isWorkingDay,
            morningStart: wh.morningStart || null,
            morningEnd: wh.morningEnd || null,
            afternoonStart: wh.afternoonStart || null,
            afternoonEnd: wh.afternoonEnd || null,
          }))
        });
      }

      // Retornar o profissional atualizado com os horários
      return await tx.professional.findUnique({
        where: { id: params.id },
        include: {
          workingHours: true,
          services: true,
        }
      });
    });

    return NextResponse.json(updatedProfessional);

  } catch (error) {
    console.error('Error updating professional:', error);
    return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);

    if (!session?.user?.id || session.user.role !== 'OWNER') {
      return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
    }

    // Verificar se o profissional existe e se pertence ao tenant do usuário
    const existingProfessional = await prisma.professional.findUnique({
      where: { id: params.id },
      include: { 
        tenant: true,
        appointments: true,
      }
    });

    if (!existingProfessional) {
      return NextResponse.json({ error: 'Profissional não encontrado' }, { status: 404 });
    }

    // Verificar se o usuário possui um tenant
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { ownedTenants: true }
    });

    if (!user?.ownedTenants?.[0]) {
      return NextResponse.json({ error: 'Estabelecimento não encontrado' }, { status: 404 });
    }

    const userTenantId = user.ownedTenants[0].id;
    
    if (existingProfessional.tenantId !== userTenantId) {
      return NextResponse.json({ error: 'Acesso negado' }, { status: 403 });
    }

    // Verificar se há agendamentos futuros
    const futureAppointments = existingProfessional.appointments.filter(
      (appointment: any) => new Date(appointment.date) > new Date()
    );

    if (futureAppointments.length > 0) {
      return NextResponse.json({ 
        error: 'Não é possível excluir profissional com agendamentos futuros. Cancele os agendamentos primeiro.' 
      }, { status: 400 });
    }

    // Soft delete - marcar como inativo ao invés de deletar
    const deactivatedProfessional = await prisma.professional.update({
      where: { id: params.id },
      data: { isActive: false }
    });

    return NextResponse.json({ 
      message: 'Profissional desativado com sucesso',
      professional: deactivatedProfessional 
    });

  } catch (error) {
    console.error('Error deleting professional:', error);
    return NextResponse.json({ error: 'Erro interno do servidor' }, { status: 500 });
  }
}
