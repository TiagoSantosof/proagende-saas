
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user) {
      return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });
    }

    // Se não for proprietário, não precisa verificar plano
    if (session.user.role !== 'OWNER') {
      return NextResponse.json({ hasValidSubscription: true });
    }

    // Verificar se o proprietário tem tenant ativo
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: {
        ownedTenants: true
      }
    });

    if (!user) {
      return NextResponse.json({ error: 'Usuário não encontrado' }, { status: 404 });
    }

    // Se não tem tenant ou tenant não tem assinatura ativa
    const hasValidSubscription = user.ownedTenants.length > 0 && 
                                  user.ownedTenants.some(tenant => 
                                    tenant.subscriptionStatus === 'ACTIVE' && 
                                    tenant.subscriptionEndsAt && 
                                    new Date(tenant.subscriptionEndsAt) > new Date()
                                  );

    return NextResponse.json({ 
      hasValidSubscription,
      needsPlan: !hasValidSubscription 
    });

  } catch (error) {
    console.error('Erro ao verificar assinatura:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
