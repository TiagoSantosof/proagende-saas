
import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/db';
import { UserRole, SubscriptionStatus, SubscriptionPlan } from '@prisma/client';

export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, password, name, phone, companyName, isOwner, purchaseData } = body;

    if (!email || !password || !name) {
      return NextResponse.json(
        { error: 'Campos obrigatórios não preenchidos' },
        { status: 400 }
      );
    }

    // Verificar se o usuário já existe
    const existingUser = await prisma.user.findUnique({
      where: { email }
    });

    if (existingUser) {
      return NextResponse.json(
        { error: 'Usuário já existe com este email' },
        { status: 400 }
      );
    }

    // Hash da senha
    const hashedPassword = await bcrypt.hash(password, 12);

    let user;

    if (isOwner && companyName) {
      // Se não há dados de compra, criar conta mas sem tenant ativo
      if (!purchaseData || !purchaseData.plan) {
        // Criar usuário proprietário sem tenant por enquanto
        user = await prisma.user.create({
          data: {
            email,
            password: hashedPassword,
            name,
            phone,
            role: UserRole.OWNER,
          }
        });
        
        // Retornar indicando que precisa escolher plano
        const { password: _, ...userWithoutPassword } = user;
        return NextResponse.json({
          message: 'Usuário criado com sucesso',
          user: userWithoutPassword,
          needsPlan: true
        });
      }

      // Criar usuário proprietário com tenant
      const slug = companyName
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9\s-]/g, '')
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-')
        .trim();

      // Verificar se o slug já existe
      const existingTenant = await prisma.tenant.findUnique({
        where: { slug }
      });

      if (existingTenant) {
        return NextResponse.json(
          { error: 'Nome da empresa já está em uso' },
          { status: 400 }
        );
      }

      // Mapear plano para enum
      let subscriptionPlan: SubscriptionPlan;
      let subscriptionEndDate: Date;
      const now = new Date();

      switch (purchaseData.plan) {
        case 'monthly':
          subscriptionPlan = SubscriptionPlan.MONTHLY;
          subscriptionEndDate = new Date(now.setMonth(now.getMonth() + 1));
          break;
        case 'quarterly':
          subscriptionPlan = SubscriptionPlan.QUARTERLY;
          subscriptionEndDate = new Date(now.setMonth(now.getMonth() + 3));
          break;
        case 'annual':
          subscriptionPlan = SubscriptionPlan.ANNUAL;
          subscriptionEndDate = new Date(now.setFullYear(now.getFullYear() + 1));
          break;
        default:
          return NextResponse.json(
            { error: 'Plano inválido' },
            { status: 400 }
          );
      }

      user = await prisma.user.create({
        data: {
          email,
          password: hashedPassword,
          name,
          phone,
          role: UserRole.OWNER,
          ownedTenants: {
            create: {
              name: companyName,
              slug,
              email,
              phone,
              subscriptionStatus: SubscriptionStatus.ACTIVE,
              subscriptionPlan: subscriptionPlan,
              subscriptionEndsAt: subscriptionEndDate,
              kiwifyCustomerId: purchaseData.purchaseId,
            }
          }
        },
        include: {
          ownedTenants: true
        }
      });
    } else {
      // Criar usuário cliente
      user = await prisma.user.create({
        data: {
          email,
          password: hashedPassword,
          name,
          phone,
          role: UserRole.CUSTOMER,
        }
      });
    }

    // Remover senha da resposta
    const { password: _, ...userWithoutPassword } = user;

    return NextResponse.json({
      message: 'Usuário criado com sucesso',
      user: userWithoutPassword
    });

  } catch (error) {
    console.error('Erro no signup:', error);
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    );
  }
}
