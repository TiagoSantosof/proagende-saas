
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import DashboardClient from './_components/dashboard-client';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

async function getDashboardData(userId: string, userRole: string) {
  try {
    if (userRole === 'OWNER') {
      // Get tenant data for owners
      const user = await prisma.user.findUnique({
        where: { id: userId },
        include: {
          ownedTenants: {
            include: {
              professionals: true,
              services: true,
              appointments: {
                include: {
                  customer: true,
                  professional: true,
                  service: true,
                },
                orderBy: {
                  date: 'desc'
                },
                take: 10
              },
              customers: true,
            }
          }
        }
      });

      if (!user?.ownedTenants?.[0]) {
        return { error: 'Estabelecimento não encontrado' };
      }

      const tenant = user.ownedTenants[0];
      
      // Calculate metrics
      const today = new Date();
      const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
      
      const monthlyAppointments = await prisma.appointment.count({
        where: {
          tenantId: tenant.id,
          date: {
            gte: startOfMonth
          }
        }
      });

      const monthlyRevenue = await prisma.appointment.aggregate({
        where: {
          tenantId: tenant.id,
          date: {
            gte: startOfMonth
          },
          status: 'COMPLETED'
        },
        _sum: {
          totalAmount: true
        }
      });

      return {
        tenant,
        stats: {
          totalProfessionals: tenant.professionals.length,
          totalServices: tenant.services.length,
          totalCustomers: tenant.customers.length,
          monthlyAppointments,
          monthlyRevenue: monthlyRevenue._sum.totalAmount || 0,
          recentAppointments: tenant.appointments
        }
      };
    } else {
      // Get customer data
      const user = await prisma.user.findUnique({
        where: { id: userId },
        include: {
          appointments: {
            include: {
              professional: true,
              service: true,
              tenant: true,
            },
            orderBy: {
              date: 'desc'
            }
          }
        }
      });

      return {
        user,
        appointments: user?.appointments || []
      };
    }
  } catch (error) {
    console.error('Error fetching dashboard data:', error);
    return { error: 'Erro ao carregar dados do dashboard' };
  }
}

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);

  if (!session?.user?.id) {
    redirect('/auth/login');
  }

  // Se for proprietário, verificar se tem plano ativo
  if (session.user.role === 'OWNER') {
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: {
        ownedTenants: true
      }
    });

    // Se não tem tenant ou tenant não tem assinatura ativa, redirecionar para planos
    const hasValidSubscription = user?.ownedTenants && user.ownedTenants.length > 0 && 
                                  user.ownedTenants.some(tenant => 
                                    tenant.subscriptionStatus === 'ACTIVE' && 
                                    tenant.subscriptionEndsAt && 
                                    new Date(tenant.subscriptionEndsAt) > new Date()
                                  );

    if (!hasValidSubscription) {
      redirect('/plans');
    }
  }

  const data = await getDashboardData(session.user.id, session.user.role || 'CUSTOMER');

  if (data.error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-red-600 mb-4">Erro</h1>
          <p className="text-gray-600">{data.error}</p>
        </div>
      </div>
    );
  }

  return <DashboardClient initialData={data} session={session} />;
}
