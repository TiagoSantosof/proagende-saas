
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import CalendarClient from './_components/calendar-client';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

async function getCalendarData(userId: string) {
  try {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        ownedTenants: {
          include: {
            appointments: {
              include: {
                customer: true,
                professional: true,
                service: true,
              },
              orderBy: {
                date: 'asc'
              }
            },
            professionals: true,
            services: true,
          }
        }
      }
    });

    if (!user?.ownedTenants?.[0]) {
      return { error: 'Estabelecimento não encontrado' };
    }

    return {
      tenant: user.ownedTenants[0],
      appointments: user.ownedTenants[0].appointments,
      professionals: user.ownedTenants[0].professionals,
      services: user.ownedTenants[0].services,
    };
  } catch (error) {
    console.error('Error fetching calendar data:', error);
    return { error: 'Erro ao carregar calendário' };
  }
}

export default async function CalendarPage() {
  const session = await getServerSession(authOptions);

  if (!session?.user?.id || session.user.role !== 'OWNER') {
    redirect('/auth/login');
  }

  const data = await getCalendarData(session.user.id);

  if (data.error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-red-600 mb-4">Erro</h1>
          <p className="text-gray-600">{data.error}</p>
        </div>
      </div>
    );
  }

  return <CalendarClient initialData={data} session={session} />;
}
