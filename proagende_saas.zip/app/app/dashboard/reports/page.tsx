
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import ReportsClient from './_components/reports-client';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

async function getReportsData(userId: string) {
  try {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        ownedTenants: {
          include: {
            appointments: {
              include: {
                customer: true,
                professional: true,
                service: true,
              }
            },
            professionals: true,
            services: true,
            customers: true,
          }
        }
      }
    });

    if (!user?.ownedTenants?.[0]) {
      return { error: 'Estabelecimento não encontrado' };
    }

    const tenant = user.ownedTenants[0];
    
    // Calculate metrics for different periods
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0);
    const startOfYear = new Date(now.getFullYear(), 0, 1);

    // Current month data
    const currentMonthAppointments = tenant.appointments.filter(apt => 
      new Date(apt.date) >= startOfMonth
    );
    
    // Last month data
    const lastMonthAppointments = tenant.appointments.filter(apt => {
      const date = new Date(apt.date);
      return date >= startOfLastMonth && date <= endOfLastMonth;
    });

    // Year data
    const yearAppointments = tenant.appointments.filter(apt => 
      new Date(apt.date) >= startOfYear
    );

    // Calculate revenue
    const calculateRevenue = (appointments: any[]) => 
      appointments
        .filter(apt => apt.status === 'COMPLETED')
        .reduce((sum, apt) => sum + (apt.totalAmount || 0), 0);

    const currentMonthRevenue = calculateRevenue(currentMonthAppointments);
    const lastMonthRevenue = calculateRevenue(lastMonthAppointments);
    const yearRevenue = calculateRevenue(yearAppointments);

    // Professional performance
    const professionalStats = tenant.professionals.map((prof: any) => {
      const profAppointments = tenant.appointments.filter(apt => apt.professionalId === prof.id);
      const monthlyAppts = profAppointments.filter(apt => new Date(apt.date) >= startOfMonth);
      
      return {
        ...prof,
        totalAppointments: profAppointments.length,
        monthlyAppointments: monthlyAppts.length,
        revenue: calculateRevenue(profAppointments),
        monthlyRevenue: calculateRevenue(monthlyAppts),
      };
    });

    // Service performance
    const serviceStats = tenant.services.map((service: any) => {
      const serviceAppointments = tenant.appointments.filter(apt => apt.serviceId === service.id);
      const monthlyAppts = serviceAppointments.filter(apt => new Date(apt.date) >= startOfMonth);
      
      return {
        ...service,
        totalAppointments: serviceAppointments.length,
        monthlyAppointments: monthlyAppts.length,
        revenue: calculateRevenue(serviceAppointments),
        monthlyRevenue: calculateRevenue(monthlyAppts),
      };
    });

    // Status distribution
    const statusDistribution = tenant.appointments.reduce((acc: any, apt: any) => {
      acc[apt.status] = (acc[apt.status] || 0) + 1;
      return acc;
    }, {});

    return {
      tenant,
      metrics: {
        currentMonth: {
          appointments: currentMonthAppointments.length,
          revenue: currentMonthRevenue,
        },
        lastMonth: {
          appointments: lastMonthAppointments.length,
          revenue: lastMonthRevenue,
        },
        year: {
          appointments: yearAppointments.length,
          revenue: yearRevenue,
        },
      },
      professionalStats,
      serviceStats,
      statusDistribution,
      totalCustomers: tenant.customers.length,
    };
  } catch (error) {
    console.error('Error fetching reports data:', error);
    return { error: 'Erro ao carregar relatórios' };
  }
}

export default async function ReportsPage() {
  const session = await getServerSession(authOptions);

  if (!session?.user?.id || session.user.role !== 'OWNER') {
    redirect('/auth/login');
  }

  const data = await getReportsData(session.user.id);

  if (data.error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-red-600 mb-4">Erro</h1>
          <p className="text-gray-600">{data.error}</p>
        </div>
      </div>
    );
  }

  return <ReportsClient initialData={data} session={session} />;
}
