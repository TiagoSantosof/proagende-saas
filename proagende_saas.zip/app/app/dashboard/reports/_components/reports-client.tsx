
'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  BarChart3, 
  ArrowLeft,
  TrendingUp,
  TrendingDown,
  Calendar,
  DollarSign,
  Users,
  Briefcase,
  Download,
  Filter
} from 'lucide-react';

interface ReportsClientProps {
  initialData: any;
  session: any;
}

export default function ReportsClient({ initialData, session }: ReportsClientProps) {
  const [selectedPeriod, setSelectedPeriod] = useState('month');
  const { tenant, metrics, professionalStats, serviceStats, statusDistribution, totalCustomers } = initialData;

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const calculatePercentageChange = (current: number, previous: number) => {
    if (previous === 0) return current > 0 ? 100 : 0;
    return ((current - previous) / previous) * 100;
  };

  const revenueChange = calculatePercentageChange(metrics.currentMonth.revenue, metrics.lastMonth.revenue);
  const appointmentsChange = calculatePercentageChange(metrics.currentMonth.appointments, metrics.lastMonth.appointments);

  const getStatusText = (status: string) => {
    const texts = {
      SCHEDULED: 'Agendado',
      CONFIRMED: 'Confirmado',
      COMPLETED: 'Concluído',
      CANCELED: 'Cancelado',
      NO_SHOW: 'Não compareceu'
    };
    return texts[status as keyof typeof texts] || status;
  };

  const getStatusColor = (status: string) => {
    const colors = {
      SCHEDULED: 'bg-yellow-500',
      CONFIRMED: 'bg-blue-500',
      COMPLETED: 'bg-green-500',
      CANCELED: 'bg-red-500',
      NO_SHOW: 'bg-gray-500'
    };
    return colors[status as keyof typeof colors] || 'bg-gray-500';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Link href="/dashboard">
                <Button variant="outline" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Voltar
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <BarChart3 className="w-6 h-6 text-blue-600" />
                <h1 className="text-xl font-semibold text-gray-900">Relatórios e Analytics</h1>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">
                <Filter className="w-4 h-4 mr-2" />
                Filtros
              </Button>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Exportar
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Main Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Receita do Mês</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {formatCurrency(metrics.currentMonth.revenue)}
              </div>
              <div className={`flex items-center text-xs ${revenueChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {revenueChange >= 0 ? <TrendingUp className="w-4 h-4 mr-1" /> : <TrendingDown className="w-4 h-4 mr-1" />}
                {Math.abs(revenueChange).toFixed(1)}% vs mês anterior
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Agendamentos do Mês</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{metrics.currentMonth.appointments}</div>
              <div className={`flex items-center text-xs ${appointmentsChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {appointmentsChange >= 0 ? <TrendingUp className="w-4 h-4 mr-1" /> : <TrendingDown className="w-4 h-4 mr-1" />}
                {Math.abs(appointmentsChange).toFixed(1)}% vs mês anterior
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total de Clientes</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalCustomers}</div>
              <p className="text-xs text-muted-foreground">
                Clientes cadastrados
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Receita Anual</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {formatCurrency(metrics.year.revenue)}
              </div>
              <p className="text-xs text-muted-foreground">
                {metrics.year.appointments} agendamentos
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Professional Performance */}
          <Card>
            <CardHeader>
              <CardTitle>Performance dos Profissionais</CardTitle>
            </CardHeader>
            <CardContent>
              {professionalStats?.length > 0 ? (
                <div className="space-y-4">
                  {professionalStats
                    .sort((a: any, b: any) => b.monthlyRevenue - a.monthlyRevenue)
                    .map((prof: any) => (
                      <div key={prof.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">{prof.name}</p>
                          <p className="text-sm text-gray-500">
                            {prof.monthlyAppointments} agendamentos este mês
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">{formatCurrency(prof.monthlyRevenue)}</p>
                          <p className="text-sm text-gray-500">este mês</p>
                        </div>
                      </div>
                    ))}
                </div>
              ) : (
                <p className="text-center text-gray-500 py-8">
                  Nenhum dado de performance disponível
                </p>
              )}
            </CardContent>
          </Card>

          {/* Service Performance */}
          <Card>
            <CardHeader>
              <CardTitle>Performance dos Serviços</CardTitle>
            </CardHeader>
            <CardContent>
              {serviceStats?.length > 0 ? (
                <div className="space-y-4">
                  {serviceStats
                    .sort((a: any, b: any) => b.monthlyRevenue - a.monthlyRevenue)
                    .map((service: any) => (
                      <div key={service.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">{service.name}</p>
                          <p className="text-sm text-gray-500">
                            {service.monthlyAppointments} agendamentos este mês
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">{formatCurrency(service.monthlyRevenue)}</p>
                          <p className="text-sm text-gray-500">este mês</p>
                        </div>
                      </div>
                    ))}
                </div>
              ) : (
                <p className="text-center text-gray-500 py-8">
                  Nenhum dado de performance disponível
                </p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Status Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Distribuição de Status dos Agendamentos</CardTitle>
          </CardHeader>
          <CardContent>
            {Object.keys(statusDistribution).length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                {Object.entries(statusDistribution).map(([status, count]) => (
                  <div key={status} className="text-center">
                    <div className={`w-12 h-12 rounded-full ${getStatusColor(status)} mx-auto mb-2 flex items-center justify-center`}>
                      <span className="text-white font-semibold">{count as number}</span>
                    </div>
                    <p className="text-sm font-medium text-gray-900">{getStatusText(status)}</p>
                    <p className="text-xs text-gray-500">{count as number} agendamentos</p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-center text-gray-500 py-8">
                Nenhum agendamento encontrado
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
