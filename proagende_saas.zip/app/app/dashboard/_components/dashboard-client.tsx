
'use client';

import { useState, useEffect } from 'react';
import { signOut } from 'next-auth/react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Calendar, 
  Users, 
  Briefcase, 
  DollarSign, 
  TrendingUp,
  Settings,
  LogOut,
  Clock,
  User,
  Building2,
  BarChart3,
  Plus,
  Eye,
  Bell,
  RefreshCw
} from 'lucide-react';
import Link from 'next/link';
import NotificationsModal from '@/components/modals/notifications-modal';
import SettingsModal from '@/components/modals/settings-modal';

interface DashboardClientProps {
  initialData: any;
  session: any;
}

export default function DashboardClient({ initialData, session }: DashboardClientProps) {
  const [activeTab, setActiveTab] = useState('overview');
  const [showNotifications, setShowNotifications] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [stats, setStats] = useState(initialData.stats || {});
  
  const isOwner = session?.user?.role === 'OWNER';

  // Auto-refresh data every 5 minutes for owners
  useEffect(() => {
    if (!isOwner) return;

    const interval = setInterval(async () => {
      await refreshDashboardData();
    }, 5 * 60 * 1000); // 5 minutes

    return () => clearInterval(interval);
  }, [isOwner]);

  const refreshDashboardData = async () => {
    setIsRefreshing(true);
    try {
      const response = await fetch('/api/dashboard/stats', {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' }
      });
      
      if (response.ok) {
        const data = await response.json();
        setStats(data.stats);
      }
    } catch (error) {
      console.error('Error refreshing dashboard data:', error);
    } finally {
      setIsRefreshing(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const formatDate = (date: string | Date) => {
    return new Date(date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusColor = (status: string) => {
    const colors = {
      SCHEDULED: 'bg-yellow-100 text-yellow-800',
      CONFIRMED: 'bg-blue-100 text-blue-800',
      COMPLETED: 'bg-green-100 text-green-800',
      CANCELED: 'bg-red-100 text-red-800',
      NO_SHOW: 'bg-gray-100 text-gray-800'
    };
    return colors[status as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const getStatusText = (status: string) => {
    const texts = {
      SCHEDULED: 'Agendado',
      CONFIRMED: 'Confirmado',
      COMPLETED: 'Concluído',
      CANCELED: 'Cancelado',
      NO_SHOW: 'Não compareceu'
    };
    return texts[status as keyof typeof texts] || status;
  };

  if (isOwner) {
    const { tenant, stats } = initialData;
    
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-4">
                <div className="bg-blue-600 p-2 rounded-lg">
                  <Calendar className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-semibold text-gray-900">ProAgenda</h1>
                  <p className="text-sm text-gray-500">{tenant?.name}</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={refreshDashboardData}
                  disabled={isRefreshing}
                >
                  <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
                  {isRefreshing ? 'Atualizando...' : 'Atualizar'}
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setShowNotifications(true)}
                >
                  <Bell className="w-4 h-4 mr-2" />
                  Notificações
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setShowSettings(true)}
                >
                  <Settings className="w-4 h-4 mr-2" />
                  Configurações
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => signOut()}
                >
                  <LogOut className="w-4 h-4 mr-2" />
                  Sair
                </Button>
              </div>
            </div>
          </div>
        </header>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Enhanced Revenue Summary */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            <Card className="md:col-span-2 lg:col-span-3">
              <CardHeader>
                <CardTitle className="text-lg flex items-center justify-between">
                  <span>Resumo de Receita</span>
                  {isRefreshing && <RefreshCw className="w-4 h-4 animate-spin text-blue-500" />}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <p className="text-sm text-gray-500 mb-2">Este Mês</p>
                    <p className="text-2xl font-bold text-green-600">
                      {formatCurrency(stats?.monthlyRevenue || 0)}
                    </p>
                    {stats?.revenueGrowth !== undefined && (
                      <p className={`text-xs flex items-center justify-center mt-1 ${
                        stats.revenueGrowth >= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        <TrendingUp className={`w-3 h-3 mr-1 ${stats.revenueGrowth < 0 ? 'rotate-180' : ''}`} />
                        {stats.revenueGrowth >= 0 ? '+' : ''}{stats.revenueGrowth}% vs mês anterior
                      </p>
                    )}
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-gray-500 mb-2">Mês Anterior</p>
                    <p className="text-2xl font-bold text-gray-600">
                      {formatCurrency(stats?.lastMonthRevenue || 0)}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      Para comparação
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-gray-500 mb-2">Agendamentos Hoje</p>
                    <p className="text-2xl font-bold text-blue-600">
                      {stats?.todayAppointments || 0}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      {stats?.weeklyAppointments || 0} esta semana
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Profissionais</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats?.totalProfessionals || 0}</div>
                <p className="text-xs text-muted-foreground">
                  Ativos no sistema
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Serviços</CardTitle>
                <Briefcase className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats?.totalServices || 0}</div>
                <p className="text-xs text-muted-foreground">
                  Disponíveis para agendamento
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Agendamentos</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats?.monthlyAppointments || 0}</div>
                <p className="text-xs text-muted-foreground">
                  Este mês
                  {stats?.appointmentGrowth !== undefined && (
                    <span className={`ml-1 ${stats.appointmentGrowth >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      ({stats.appointmentGrowth >= 0 ? '+' : ''}{stats.appointmentGrowth}%)
                    </span>
                  )}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Receita Total</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {formatCurrency(stats?.monthlyRevenue || 0)}
                </div>
                <p className="text-xs text-muted-foreground">
                  Este mês
                  {stats?.revenueGrowth !== undefined && (
                    <span className={`ml-1 ${stats.revenueGrowth >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      ({stats.revenueGrowth >= 0 ? '+' : ''}{stats.revenueGrowth}%)
                    </span>
                  )}
                  {isRefreshing && <span className="ml-2 text-blue-500">•</span>}
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-4 mb-8">
            <Link href="/dashboard/calendar">
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Calendar className="w-4 h-4 mr-2" />
                Ver Calendário
              </Button>
            </Link>
            <Link href="/dashboard/professionals">
              <Button variant="outline">
                <Users className="w-4 h-4 mr-2" />
                Gerenciar Profissionais
              </Button>
            </Link>
            <Link href="/dashboard/services">
              <Button variant="outline">
                <Briefcase className="w-4 h-4 mr-2" />
                Gerenciar Serviços
              </Button>
            </Link>
            <Link href="/dashboard/reports">
              <Button variant="outline">
                <BarChart3 className="w-4 h-4 mr-2" />
                Relatórios
              </Button>
            </Link>
          </div>

          {/* Recent Appointments */}
          <Card>
            <CardHeader>
              <CardTitle>Agendamentos Recentes</CardTitle>
            </CardHeader>
            <CardContent>
              {stats?.recentAppointments?.length > 0 ? (
                <div className="space-y-4">
                  {stats.recentAppointments.map((appointment: any, index: number) => (
                    <div key={appointment.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3">
                          <div className="flex-shrink-0">
                            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                              <User className="w-5 h-5 text-blue-600" />
                            </div>
                          </div>
                          <div className="flex-1">
                            <p className="font-medium text-gray-900">{appointment.customer?.name}</p>
                            <p className="text-sm text-gray-500">
                              {appointment.service?.name} • {appointment.professional?.name}
                            </p>
                            <p className="text-sm text-gray-500">
                              <Clock className="w-4 h-4 inline mr-1" />
                              {formatDate(appointment.date)}
                            </p>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Badge className={getStatusColor(appointment.status)}>
                          {getStatusText(appointment.status)}
                        </Badge>
                        <span className="font-medium text-gray-900">
                          {appointment.totalAmount ? formatCurrency(appointment.totalAmount) : '-'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Nenhum agendamento encontrado</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Modals */}
        <NotificationsModal 
          isOpen={showNotifications} 
          onClose={() => setShowNotifications(false)} 
        />
        
        <SettingsModal 
          isOpen={showSettings} 
          onClose={() => setShowSettings(false)}
          tenantData={tenant}
        />
      </div>
    );
  }

  // Customer Dashboard
  const { user, appointments } = initialData;
  
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="bg-green-600 p-2 rounded-lg">
                <User className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">Meus Agendamentos</h1>
                <p className="text-sm text-gray-500">Olá, {session?.user?.name}!</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => signOut()}
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sair
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Actions */}
        <div className="mb-8">
          <Button className="bg-green-600 hover:bg-green-700">
            <Plus className="w-4 h-4 mr-2" />
            Novo Agendamento
          </Button>
        </div>

        {/* Appointments */}
        <Card>
          <CardHeader>
            <CardTitle>Seus Agendamentos</CardTitle>
          </CardHeader>
          <CardContent>
            {appointments?.length > 0 ? (
              <div className="space-y-4">
                {appointments.map((appointment: any) => (
                  <div key={appointment.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3">
                        <div className="flex-shrink-0">
                          <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                            <Building2 className="w-5 h-5 text-green-600" />
                          </div>
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-gray-900">{appointment.tenant?.name}</p>
                          <p className="text-sm text-gray-500">
                            {appointment.service?.name} • {appointment.professional?.name}
                          </p>
                          <p className="text-sm text-gray-500">
                            <Clock className="w-4 h-4 inline mr-1" />
                            {formatDate(appointment.date)}
                          </p>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Badge className={getStatusColor(appointment.status)}>
                        {getStatusText(appointment.status)}
                      </Badge>
                      <Button variant="outline" size="sm">
                        <Eye className="w-4 h-4 mr-2" />
                        Ver
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500 mb-4">Você ainda não tem agendamentos</p>
                <Button className="bg-green-600 hover:bg-green-700">
                  <Plus className="w-4 h-4 mr-2" />
                  Fazer Primeiro Agendamento
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Modals */}
        <NotificationsModal 
          isOpen={showNotifications} 
          onClose={() => setShowNotifications(false)} 
        />
        
        <SettingsModal 
          isOpen={showSettings} 
          onClose={() => setShowSettings(false)}
          tenantData={initialData.tenant}
        />
      </div>
    </div>
  );
}
