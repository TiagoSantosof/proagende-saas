
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import ProfessionalsClient from './_components/professionals-client';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

async function getProfessionalsData(userId: string) {
  try {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        ownedTenants: {
          include: {
            professionals: {
              include: {
                appointments: {
                  include: {
                    customer: true,
                    service: true,
                  }
                },
                services: true,
              }
            }
          }
        }
      }
    });

    if (!user?.ownedTenants?.[0]) {
      return { error: 'Estabelecimento não encontrado' };
    }

    return {
      tenant: user.ownedTenants[0],
      professionals: user.ownedTenants[0].professionals,
    };
  } catch (error) {
    console.error('Error fetching professionals data:', error);
    return { error: 'Erro ao carregar profissionais' };
  }
}

export default async function ProfessionalsPage() {
  const session = await getServerSession(authOptions);

  if (!session?.user?.id || session.user.role !== 'OWNER') {
    redirect('/auth/login');
  }

  const data = await getProfessionalsData(session.user.id);

  if (data.error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-red-600 mb-4">Erro</h1>
          <p className="text-gray-600">{data.error}</p>
        </div>
      </div>
    );
  }

  return <ProfessionalsClient initialData={data} session={session} />;
}
