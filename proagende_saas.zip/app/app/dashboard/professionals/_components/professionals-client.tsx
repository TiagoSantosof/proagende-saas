
'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import ProfessionalModal from '@/components/modals/professional-modal';
import { 
  Users, 
  ArrowLeft,
  Plus,
  Search,
  User,
  Mail,
  Phone,
  Clock,
  Edit,
  Trash2,
  Eye
} from 'lucide-react';

interface ProfessionalsClientProps {
  initialData: any;
  session: any;
}

export default function ProfessionalsClient({ initialData, session }: ProfessionalsClientProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [isProfessionalModalOpen, setIsProfessionalModalOpen] = useState(false);
  const [editingProfessional, setEditingProfessional] = useState(null);
  const [modalMode, setModalMode] = useState<'create' | 'edit'>('create');
  const { tenant, professionals } = initialData;

  const filteredProfessionals = professionals?.filter((prof: any) =>
    prof.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    prof.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    prof.specialty?.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  const getStatusColor = (status: string) => {
    const colors = {
      ACTIVE: 'bg-green-100 text-green-800',
      INACTIVE: 'bg-gray-100 text-gray-800',
      VACATION: 'bg-yellow-100 text-yellow-800',
    };
    return colors[status as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const getStatusText = (status: string) => {
    const texts = {
      ACTIVE: 'Ativo',
      INACTIVE: 'Inativo',
      VACATION: 'Férias',
    };
    return texts[status as keyof typeof texts] || status;
  };

  const handleCreateProfessional = () => {
    setModalMode('create');
    setEditingProfessional(null);
    setIsProfessionalModalOpen(true);
  };

  const handleEditProfessional = (professional: any) => {
    setModalMode('edit');
    setEditingProfessional(professional);
    setIsProfessionalModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsProfessionalModalOpen(false);
    setEditingProfessional(null);
    setModalMode('create');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Link href="/dashboard">
                <Button variant="outline" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Voltar
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <Users className="w-6 h-6 text-blue-600" />
                <h1 className="text-xl font-semibold text-gray-900">Gerenciar Profissionais</h1>
              </div>
            </div>
            
            <Button 
              className="bg-blue-600 hover:bg-blue-700"
              onClick={handleCreateProfessional}
            >
              <Plus className="w-4 h-4 mr-2" />
              Novo Profissional
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search */}
        <div className="mb-6">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              type="text"
              placeholder="Buscar profissionais..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total de Profissionais</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{professionals?.length || 0}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Profissionais Ativos</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {professionals?.filter((p: any) => p.status === 'ACTIVE').length || 0}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Em Férias</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {professionals?.filter((p: any) => p.status === 'VACATION').length || 0}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Professionals List */}
        <Card>
          <CardHeader>
            <CardTitle>Profissionais ({filteredProfessionals.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {filteredProfessionals.length > 0 ? (
              <div className="space-y-4">
                {filteredProfessionals.map((professional: any) => (
                  <div key={professional.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <User className="w-6 h-6 text-blue-600" />
                      </div>
                      
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <h3 className="font-medium text-gray-900">{professional.name}</h3>
                          <Badge className={getStatusColor(professional.status || 'ACTIVE')}>
                            {getStatusText(professional.status || 'ACTIVE')}
                          </Badge>
                        </div>
                        
                        <div className="flex items-center space-x-4 mt-1 text-sm text-gray-500">
                          {professional.email && (
                            <div className="flex items-center space-x-1">
                              <Mail className="w-4 h-4" />
                              <span>{professional.email}</span>
                            </div>
                          )}
                          {professional.phone && (
                            <div className="flex items-center space-x-1">
                              <Phone className="w-4 h-4" />
                              <span>{professional.phone}</span>
                            </div>
                          )}
                        </div>
                        
                        {professional.specialty && (
                          <p className="text-sm text-gray-600 mt-1">
                            Especialidade: {professional.specialty}
                          </p>
                        )}
                        
                        {professional.workingHours && (
                          <div className="flex items-center space-x-1 mt-1 text-sm text-gray-500">
                            <Clock className="w-4 h-4" />
                            <span>Horário: {professional.workingHours}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleEditProfessional(professional)}
                      >
                        <Eye className="w-4 h-4 mr-2" />
                        Ver
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleEditProfessional(professional)}
                      >
                        <Edit className="w-4 h-4 mr-2" />
                        Editar
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="text-red-600 border-red-200 hover:bg-red-50"
                        onClick={() => {
                          if (confirm('Tem certeza que deseja desativar este profissional?')) {
                            // TODO: Implementar deleção/desativação
                            console.log('Desativar profissional:', professional.id);
                          }
                        }}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500 mb-4">
                  {searchTerm ? 'Nenhum profissional encontrado' : 'Nenhum profissional cadastrado'}
                </p>
                {!searchTerm && (
                  <Button 
                    className="bg-blue-600 hover:bg-blue-700"
                    onClick={handleCreateProfessional}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Cadastrar Primeiro Profissional
                  </Button>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      <ProfessionalModal
        isOpen={isProfessionalModalOpen}
        onClose={handleCloseModal}
        professional={editingProfessional}
        mode={modalMode}
      />
    </div>
  );
}
