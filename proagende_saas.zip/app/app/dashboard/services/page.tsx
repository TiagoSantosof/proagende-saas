
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { redirect } from 'next/navigation';
import ServicesClient from './_components/services-client';
import { prisma } from '@/lib/db';

export const dynamic = 'force-dynamic';

async function getServicesData(userId: string) {
  try {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        ownedTenants: {
          include: {
            services: {
              include: {
                appointments: {
                  include: {
                    customer: true,
                    professional: true,
                  }
                },
                professionals: true,
              }
            },
            professionals: true,
          }
        }
      }
    });

    if (!user?.ownedTenants?.[0]) {
      return { error: 'Estabelecimento não encontrado' };
    }

    return {
      tenant: user.ownedTenants[0],
      services: user.ownedTenants[0].services,
      professionals: user.ownedTenants[0].professionals,
    };
  } catch (error) {
    console.error('Error fetching services data:', error);
    return { error: 'Erro ao carregar serviços' };
  }
}

export default async function ServicesPage() {
  const session = await getServerSession(authOptions);

  if (!session?.user?.id || session.user.role !== 'OWNER') {
    redirect('/auth/login');
  }

  const data = await getServicesData(session.user.id);

  if (data.error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-red-600 mb-4">Erro</h1>
          <p className="text-gray-600">{data.error}</p>
        </div>
      </div>
    );
  }

  return <ServicesClient initialData={data} session={session} />;
}
