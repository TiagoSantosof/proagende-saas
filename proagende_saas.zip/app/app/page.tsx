import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Calendar, 
  Users, 
  Clock, 
  BarChart3, 
  Check, 
  Star, 
  ArrowRight, 
  Smartphone,
  Globe,
  Shield,
  Zap,
  Crown,
  Sparkles
} from 'lucide-react';

export default function Home() {
  const features = [
    {
      icon: Calendar,
      title: 'Calendário Inteligente',
      description: 'Visualize e gerencie todos os agendamentos de forma intuitiva'
    },
    {
      icon: Users,
      title: 'Multi-profissional',
      description: 'Gerencie equipes completas com controle individual de horários'
    },
    {
      icon: Clock,
      title: 'Agendamento Online',
      description: 'Clientes podem agendar 24/7 através da plataforma web'
    },
    {
      icon: BarChart3,
      title: 'Relatórios Detalhados',
      description: 'Acompanhe métricas e performance do seu negócio'
    },
    {
      icon: Smartphone,
      title: 'Design Responsivo',
      description: 'Funciona perfeitamente em qualquer dispositivo'
    },
    {
      icon: Shield,
      title: 'Dados Seguros',
      description: 'Proteção avançada para informações dos clientes'
    }
  ];

  const plans = [
    {
      name: 'Mensal',
      price: 'R$ 89',
      period: '/mês',
      originalPrice: null,
      discount: null,
      popular: false,
      features: [
        'Agendamentos ilimitados',
        'Até 5 profissionais',
        'Calendário online',
        'Relatórios básicos',
        'Suporte por email',
        'App responsivo'
      ]
    },
    {
      name: 'Trimestral',
      price: 'R$ 199',
      period: '/trimestre',
      originalPrice: 'R$ 267',
      discount: '25% OFF',
      popular: true,
      features: [
        'Todos os recursos do Mensal',
        'Até 10 profissionais',
        'Relatórios avançados',
        'Suporte prioritário',
        'Integração com WhatsApp',
        'Backup automático'
      ]
    },
    {
      name: 'Anual',
      price: '10x R$ 69,90',
      period: '',
      originalPrice: 'R$ 1.068',
      discount: '35% OFF',
      popular: false,
      features: [
        'Todos os recursos do Trimestral',
        'Profissionais ilimitados',
        'API personalizada',
        'Suporte 24/7',
        'Treinamento dedicado',
        'Customizações exclusivas'
      ]
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="border-b bg-white/95 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="bg-blue-600 p-2 rounded-lg">
                <Calendar className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">ProAgenda</span>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="#pricing">
                <Button variant="ghost">Planos</Button>
              </Link>
              <Link href="/auth/login">
                <Button variant="ghost">Entrar</Button>
              </Link>
              <Link href="/auth/register">
                <Button className="bg-blue-600 hover:bg-blue-700">
                  Criar Conta
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 via-white to-purple-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex justify-center mb-8">
              <div className="flex items-center space-x-2 bg-blue-100 px-4 py-2 rounded-full">
                <Sparkles className="w-5 h-5 text-blue-600" />
                <span className="text-blue-800 text-sm font-medium">Sistema de Agendamentos Profissional</span>
              </div>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Transforme seu negócio com
              <span className="text-blue-600 block">agendamentos inteligentes</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Plataforma completa para salões, clínicas, consultórios e estabelecimentos de serviços. 
              Gerencie profissionais, horários e clientes de forma simples e eficiente.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/auth/register">
                <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-3">
                  Comece Gratuitamente
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Link href="#features">
                <Button size="lg" variant="outline" className="text-lg px-8 py-3">
                  Ver Recursos
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Tudo que você precisa para crescer
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Recursos desenvolvidos especificamente para profissionais que querem 
              oferecer a melhor experiência aos seus clientes.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardHeader>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                    <feature.icon className="w-6 h-6 text-blue-600" />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Planos que se adaptam ao seu negócio
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Escolha o plano ideal para o seu estabelecimento. 
              Todos incluem suporte e atualizações gratuitas.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {plans.map((plan, index) => (
              <Card 
                key={index} 
                className={`relative ${plan.popular ? 'border-2 border-blue-500 shadow-2xl scale-105' : 'border shadow-lg'}`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-blue-600 text-white px-4 py-1">
                      <Crown className="w-4 h-4 mr-1" />
                      Mais Popular
                    </Badge>
                  </div>
                )}
                
                <CardHeader className="text-center pb-6">
                  <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
                  <div className="mt-4">
                    {plan.discount && (
                      <div className="mb-2">
                        <Badge variant="destructive" className="text-xs">
                          {plan.discount}
                        </Badge>
                        <p className="text-sm text-gray-500 line-through mt-1">
                          {plan.originalPrice}
                        </p>
                      </div>
                    )}
                    <div className="flex items-baseline justify-center">
                      <span className="text-4xl font-bold text-gray-900">{plan.price}</span>
                      <span className="text-gray-500 ml-1">{plan.period}</span>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent>
                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center">
                        <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                        <span className="text-gray-600">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Link 
                    href={
                      plan.name === 'Mensal' ? 'https://pay.kiwify.com.br/UQA4Ci5' : 
                      plan.name === 'Trimestral' ? 'https://pay.kiwify.com.br/VRRAbUC' : 
                      'https://pay.kiwify.com.br/rSp1Joc'
                    }
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Button 
                      className={`w-full ${
                        plan.popular 
                          ? 'bg-blue-600 hover:bg-blue-700' 
                          : 'bg-gray-900 hover:bg-gray-800'
                      }`}
                      size="lg"
                    >
                      Começar Agora
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Pronto para revolucionar seu negócio?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Junte-se a centenas de profissionais que já transformaram 
            sua gestão de agendamentos com o ProAgenda.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/auth/register">
              <Button size="lg" variant="secondary" className="text-lg px-8 py-3">
                Começar Gratuitamente
                <Zap className="ml-2 w-5 h-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <div className="bg-blue-600 p-2 rounded-lg">
                <Calendar className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold">ProAgenda</span>
            </div>
            <p className="text-gray-400 mb-6">
              Plataforma SaaS para gestão de agendamentos profissionais
            </p>
            <div className="flex justify-center space-x-6">
              <Link href="/auth/login" className="text-gray-400 hover:text-white transition-colors">
                Entrar
              </Link>
              <Link href="/auth/register" className="text-gray-400 hover:text-white transition-colors">
                Cadastro
              </Link>
            </div>
            <div className="border-t border-gray-800 mt-8 pt-8">
              <p className="text-gray-400 text-sm">
                © 2024 ProAgenda. Todos os direitos reservados.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}