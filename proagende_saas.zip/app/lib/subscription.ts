
import { prisma } from '@/lib/db';
import { SubscriptionStatus } from '@prisma/client';

/**
 * Verifica e atualiza automaticamente o status de assinaturas expiradas
 * @param userId - ID do usuário para verificar (opcional)
 * @returns Promise<void>
 */
export async function checkAndUpdateExpiredSubscriptions(userId?: string) {
  try {
    const now = new Date();
    
    // Buscar tenants com assinatura ativa mas que já venceram
    const expiredTenants = await prisma.tenant.findMany({
      where: {
        subscriptionStatus: SubscriptionStatus.ACTIVE,
        subscriptionEndsAt: {
          lt: now // Data de vencimento menor que agora
        },
        ...(userId && { ownerId: userId })
      }
    });

    // Atualizar status para EXPIRED
    if (expiredTenants.length > 0) {
      await prisma.tenant.updateMany({
        where: {
          id: { in: expiredTenants.map(t => t.id) }
        },
        data: {
          subscriptionStatus: SubscriptionStatus.EXPIRED
        }
      });

      console.log(`Atualizados ${expiredTenants.length} tenants para status EXPIRED`);
    }
  } catch (error) {
    console.error('Erro ao verificar assinaturas expiradas:', error);
  }
}

/**
 * Verifica se um usuário proprietário tem assinatura ativa
 * @param userId - ID do usuário
 * @returns Promise<{ isActive: boolean, tenant?: any }>
 */
export async function checkUserSubscription(userId: string) {
  const maxRetries = 3;
  let retries = 0;
  
  while (retries < maxRetries) {
    try {
      // Primeiro, atualizar possíveis expirados
      await checkAndUpdateExpiredSubscriptions(userId);
      
      // Buscar tenant do usuário com timeout
      const tenant = await Promise.race([
        prisma.tenant.findFirst({
          where: {
            ownerId: userId,
            subscriptionStatus: SubscriptionStatus.ACTIVE
          }
        }),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Database query timeout')), 10000)
        )
      ]);

      return {
        isActive: !!tenant,
        tenant: tenant || null
      };
    } catch (error) {
      retries++;
      console.error(`Erro ao verificar assinatura do usuário (tentativa ${retries}/${maxRetries}):`, error);
      
      if (retries >= maxRetries) {
        // Após esgotar as tentativas, assumir que não há assinatura ativa para segurança
        console.error('Máximo de tentativas excedido para verificação de assinatura');
        return { isActive: false, tenant: null };
      }
      
      // Aguardar antes de tentar novamente
      await new Promise(resolve => setTimeout(resolve, 1000 * retries));
    }
  }
  
  return { isActive: false, tenant: null };
}

/**
 * Obtém informações detalhadas da assinatura de um usuário
 * @param userId - ID do usuário
 * @returns Promise<SubscriptionInfo | null>
 */
export async function getUserSubscriptionInfo(userId: string) {
  try {
    await checkAndUpdateExpiredSubscriptions(userId);
    
    const tenant = await prisma.tenant.findFirst({
      where: { ownerId: userId },
      select: {
        id: true,
        name: true,
        subscriptionStatus: true,
        subscriptionPlan: true,
        subscriptionEndsAt: true,
        createdAt: true
      }
    });

    if (!tenant) return null;

    const now = new Date();
    const isExpired = tenant.subscriptionEndsAt ? tenant.subscriptionEndsAt < now : false;
    const daysUntilExpiration = tenant.subscriptionEndsAt 
      ? Math.ceil((tenant.subscriptionEndsAt.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))
      : null;

    return {
      ...tenant,
      isExpired,
      daysUntilExpiration,
      isActive: tenant.subscriptionStatus === SubscriptionStatus.ACTIVE && !isExpired
    };
  } catch (error) {
    console.error('Erro ao obter informações da assinatura:', error);
    return null;
  }
}

export interface SubscriptionInfo {
  id: string;
  name: string;
  subscriptionStatus: SubscriptionStatus;
  subscriptionPlan: string | null;
  subscriptionEndsAt: Date | null;
  createdAt: Date;
  isExpired: boolean;
  daysUntilExpiration: number | null;
  isActive: boolean;
}
