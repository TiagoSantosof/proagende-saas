import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

// Verificar se DATABASE_URL existe
if (!process.env.DATABASE_URL) {
  console.error('DATABASE_URL não encontrada no ambiente');
  throw new Error('DATABASE_URL is required');
}

export const prisma = globalForPrisma.prisma ?? new PrismaClient({
  log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
  datasources: {
    db: {
      url: process.env.DATABASE_URL,
    },
  },
})

// Garantir que a conexão seja estabelecida
prisma.$connect().catch((error) => {
  console.error('Falha ao conectar com o banco de dados:', error);
});

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma
