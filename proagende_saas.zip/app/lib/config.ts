
// Configurações da aplicação
export const config = {
  database: {
    url: process.env.DATABASE_URL,
    connectionTimeout: 15000,
    queryTimeout: 10000,
    retryAttempts: 3,
    retryDelay: 1000,
  },
  auth: {
    secret: process.env.NEXTAUTH_SECRET,
    url: process.env.NEXTAUTH_URL,
  },
  app: {
    name: 'ProAgenda SaaS',
    version: '1.0.0',
    environment: process.env.NODE_ENV || 'development',
  },
  subscription: {
    checkTimeout: 10000,
    gracefulFailover: true, // Permite acesso temporário em caso de erro de conexão
  }
};

// Validação de configurações críticas
export function validateConfig() {
  const errors: string[] = [];

  if (!config.database.url) {
    errors.push('DATABASE_URL is required');
  }

  if (!config.auth.secret) {
    errors.push('NEXTAUTH_SECRET is required');
  }

  if (!config.auth.url) {
    errors.push('NEXTAUTH_URL is required');
  }

  if (errors.length > 0) {
    console.error('Configuration errors:', errors);
    throw new Error(`Configuration validation failed: ${errors.join(', ')}`);
  }
}

// Inicializar validação
try {
  validateConfig();
  console.log('✅ Configuration validated successfully');
} catch (error: any) {
  console.error('❌ Configuration validation failed:', error?.message || error);
  if (process.env.NODE_ENV === 'production') {
    process.exit(1);
  }
}
