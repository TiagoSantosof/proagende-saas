
# 🚀 Deploy com GitHub + Vercel

## Passo 1: Criar Repositório no GitHub

1. **Acesse**: https://github.com
2. **Clique**: "New repository" (botão verde)
3. **Nome**: `proagende-saas`
4. **Visibilidade**: Public (gratuito) ou Private (se preferir)
5. **NÃO** marque "Add README" (já temos arquivos)
6. **Clique**: "Create repository"

## Passo 2: Fazer Upload dos Arquivos

### Opção A: Upload Manual (Mais Fácil)
1. **Baixe** todos os arquivos do projeto
2. **No GitHub**, clique "uploading an existing file"  
3. **Arraste** a pasta `app` completa
4. **Commit**: "Initial commit - ProAgenda SaaS"

### Opção B: Via Git (Mais Profissional)
```bash
# No seu computador local
git init
git add .
git commit -m "Initial commit - ProAgenda SaaS"
git remote add origin https://github.com/SEU-USUARIO/proagende-saas.git
git push -u origin main
```

## Passo 3: Conectar Vercel ao GitHub

1. **Acesse**: https://vercel.com
2. **Login** com GitHub
3. **Import Project**
4. **Selecione**: seu repositório `proagende-saas`
5. **Configure** as variáveis de ambiente:

```env
DATABASE_URL=postgresql://role_f073e813:xX7sZVUJ1xKaUodtgHIWOPBhSR9GQvs1@db-f073e813.db001.hosteddb.reai.io:5432/f073e813?connect_timeout=15
NEXTAUTH_URL=https://SEUDOMINIO.com
NEXTAUTH_SECRET=d39RF1jOAz8Z7A3Xvj6DfpdoNMJoSQDM
```

## Passo 4: Deploy Automático
- ✅ A cada push no GitHub → deploy automático na Vercel
- ✅ Preview deployments para branches
- ✅ Rollback automático em caso de erro

## Vantagens desta Abordagem:
- 🆓 **GitHub**: Repositório gratuito
- 🚀 **Deploy**: Automático e rápido  
- 🔒 **Backup**: Código seguro no GitHub
- 👥 **Colaboração**: Fácil para trabalhar em equipe
- 📈 **Escalabilidade**: Vercel otimizada para Next.js

## URLs Finais:
- **Código**: https://github.com/SEU-USUARIO/proagende-saas
- **App**: https://seudominio.com
- **Preview**: https://proagende-saas.vercel.app
