
# 🚀 Guia de Deploy - ProAgenda SaaS

## Pré-requisitos
- Conta no GitHub
- Domínio próprio registrado
- Conta na Vercel (gratuita)

## Passo a Passo Completo

### 1. **Preparar o Repositório GitHub**
```bash
# Inicializar git (se não existir)
git init
git add .
git commit -m "Initial commit - ProAgenda SaaS"

# Conectar ao GitHub
git remote add origin https://github.com/SEU-USUARIO/SEU-REPOSITORIO.git
git push -u origin main
```

### 2. **Deploy na Vercel**
1. Acesse: https://vercel.com
2. Conecte sua conta GitHub
3. Clique em "Import Project"
4. Selecione seu repositório
5. Configure as variáveis de ambiente:
   - `DATABASE_URL`: Sua URL do PostgreSQL
   - `NEXTAUTH_URL`: https://seudominio.com
   - `NEXTAUTH_SECRET`: Gere um novo em https://generate-secret.vercel.app/32

### 3. **Configurar Domínio Personalizado**
1. No painel da Vercel, vá em "Settings" > "Domains"
2. Adicione seu domínio: `seudominio.com`
3. Configure os DNS no seu registrador:

**Para domínio raiz (seudominio.com):**
```
Type: A
Name: @
Value: 76.76.19.61
```

**Para subdomínio (www.seudominio.com):**
```
Type: CNAME
Name: www
Value: cname.vercel-dns.com
```

### 4. **Verificação Final**
- SSL será configurado automaticamente
- Teste todas as funcionalidades
- Verifique autenticação
- Teste criação de contas

## 🎯 URLs Finais
- **Produção**: https://seudominio.com
- **Preview**: https://seu-projeto.vercel.app

## 📞 Suporte
Se precisar de ajuda, consulte:
- Documentação Vercel: https://vercel.com/docs
- Documentação Next.js: https://nextjs.org/docs
